### 项目结构介绍

- build 打包编译相关的方法和配置
- dist 编译产物
- packages 组件代码 (monorepo)
- play 开发时调试使用
- typings 类型声明
- tsconfig ts配置

### 开发说明

采用 pnpm 进行包管理，使用 gulp+rollup 做编译构建

首先需要安装pnpm , node 版本需要 >= 12.17.x

通过 npm 安装
```
npm install -g pnpm
```

通过 npx 安装
```
npx pnpm add -g pnpm
```

更多 pnpm 文档请查阅 [pnpm官网](https://pnpm.io/zh/installation)

### 开发调试

play 目录下的项目用于在开发中调试组件，组件可以在此项目中引用，通过 run dev 命令来启动项目查看效果