export declare const UPDATE_MODEL_EVENT = "update:modelValue";
export declare const QUERY_SEARCH = "querySearch";
