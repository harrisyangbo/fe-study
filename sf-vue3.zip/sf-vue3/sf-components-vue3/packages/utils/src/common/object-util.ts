/**
 * 根据字符串形式的属性路径取值和赋值
 */
 const propertyPathRegex = /^[\$\w]+(\[\d+\])*(\.[\$\w]+(\[\d+\])*)*$/; // eslint-disable-line
 const splitter = /[\.\[\]]/; // eslint-disable-line

export function setProperty(target, propertyPath, value) {
	 if (propertyPathRegex.test(propertyPath)) {
		 const paths = parsePath(propertyPath);
		 for (let i = 0; i < paths.length; ++i) {
			 const p = paths[i];
			 if (i === paths.length - 1) {
				 // eslint-disable-next-line no-param-reassign
				 target[p] = value;
			 } else {
				 if (target[p] === undefined || target[p] === null) {
					 const nextP = paths[i + 1];
					 if (typeof nextP === 'number') {
						 // eslint-disable-next-line no-param-reassign
						 target[p] = [];
					 } else {
						 // eslint-disable-next-line no-param-reassign
						 target[p] = {};
					 }
				 }
				 // eslint-disable-next-line no-param-reassign
				 target = target[p];
			 }
		 }
	 } else {
		 throw new Error('invalid property path!');
	 }
}

export function getProperty(obj, propertyPath) {
  if (propertyPathRegex.test(propertyPath)) {
    const paths = parsePath(propertyPath);
    let objCopy = {
      ...obj,
    };
    paths.forEach((item) => {
      if (!obj) {
        throw new Error(`property [${propertyPath}] is not defined`);
      };
      objCopy = obj[item];
    });
    return objCopy;
  }
  throw new Error('invalid property path!');
}

function parsePath(path) {
	 const arr = path.split(splitter);
	 const ret: string | number[] = [];
	 arr.forEach((elem) => {
		 if (elem) {
			 const n = Number(elem);
			 if (isNaN(n)) {
				 ret.push(elem);
			 } else {
				 ret.push(n);
			 }
		 }
	 });
	 return ret;
}

/**
	* 遍历对象上的属性名称，过滤出以指定后缀结尾的属性和它的值，组装成一个新对象返回出来
	* @param {要读取的对象} obj
	* @param {属性名称后缀} propertyEndWithName
	*/
export function getPropertyEndWith(obj, propertyEndWithName) {
	 const regex = new RegExp(`(^|\\.)${propertyEndWithName}(#\\d+)?$`);
	 return Object.keys(obj).filter(k => regex.test(k))
    .reduce((result, k) => {
		 // eslint-disable-next-line no-param-reassign
		 result[k] = obj[k];
		 return result;
	 }, {});
}

