export const UPDATE_MODEL_EVENT = 'update:modelValue';
export const QUERY_SEARCH = 'querySearch';
