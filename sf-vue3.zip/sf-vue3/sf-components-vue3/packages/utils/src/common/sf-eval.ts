/**
 * 支持Proxy的运行时采用下列方法模拟严格的作用域
 */
// 动态解析脚本的代码，由于目前未引入babel编译，不支持太高级的es语法特性，建议使用兼容程度较高的es5以下语法

import { decodeHTML } from './html-escape';

const sandboxProxies = new WeakMap();

const compileCode = (src) => {
  const str = `with (sandbox) {${src}}`;
  // eslint-disable-next-line no-new-func
  const code = new Function('sandbox', 'params', str);
  return  (sandbox, params) => {
    if (!sandboxProxies.has(sandbox)) {
      const sandboxProxy = new Proxy(sandbox, { has, get });
      sandboxProxies.set(sandbox, sandboxProxy);
    }
    return code.apply(this, [sandboxProxies.get(sandbox), params]);
  };
};

function has() {
  return true;
}

function get(target, key) {
  if (key === Symbol.unscopables) return undefined;
  return target[key];
}

/**
 * 不支持Proxy的运行时采用下列方法模拟作用域，但是无法屏蔽全局作用域
 */
function compileCodeWithoutProxy(src) {
  const str = `with (sandbox) {${src}}`;
  // eslint-disable-next-line no-new-func
  return new Function('sandbox', 'params', str);
}

function createRunnableScope(src) {
  if (window.Proxy) {
    return compileCode(src);
  }
  return compileCodeWithoutProxy(src);
}

export default {
  runExpression(expression, thisObject, context = {}) {
    const exp = decodeHTML(expression);
    const fn = createRunnableScope(`return ${exp};`);
    try {
      return Boolean(fn.call(thisObject, context));
    } catch (e: any) {
      throw new Error(e.message ? e.message : 'invalid expression');
    }
  },
  runFunction(functionScript, thisObject, context = {}, ...params) {
    const fScript = decodeHTML(functionScript);
    const fn = createRunnableScope(`return (${fScript}).apply(this, params);`);
    try {
      const newContext = Object.assign({}, context, { console }); // debug
      return fn.apply(thisObject, [newContext, params]);
    } catch (e: any) {
      throw new Error(e.message ? e.message : 'invalid function');
    }
  },
  runFunctionWithoutSandbox(functionScript, thisObject, context = {}, ...params) {
    const fScript = decodeHTML(functionScript);
    const fn = compileCodeWithoutProxy(`return (${fScript}).apply(this, params);`);
    try {
      return fn.apply(thisObject, [context, params]);
    } catch (e: any) {
      throw new Error(e.message ? e.message : 'invalid function');
    }
  },
};
