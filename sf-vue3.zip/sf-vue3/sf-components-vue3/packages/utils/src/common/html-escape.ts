export const encodeHTML = html => html.replace(/[<>&"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[c]));

export const decodeHTML = (txt) => {
  const arrEntities = { lt: '<', gt: '>', nbsp: ' ', amp: '&', quot: '"' };
  return txt.replace(/&*(lt|gt|nbsp|amp|quot);/ig, (all, t) =>  arrEntities[t]);
};
