import componentRegister from './component-register';
import logicHook from './logic-hook';
import logicCall from './logic-call';
export {
  componentRegister,
  logicHook,
  logicCall,
};
