// 权限处理相关方法
// TODO: 使用新的模版字符处理包
// import TemplateAnalyzer from 'sailfish-template-analyzer';

export function checkAuth() {
  /**
	 * @params thisVueInstance = {}
	 * **/
  // const { isRender, isShow } = innerCheckAuth(thisVueInstance);
  return true;
}

// function innerCheckAuth(thisVueInstance) {
//   let showCondition: any = true;
//   if (thisVueInstance.showCondition !== undefined
// 		&& thisVueInstance.showCondition !== null
// 		&& thisVueInstance.showCondition !== '') {
//     showCondition = thisVueInstance.showCondition;
//   }
//   const authCode = thisVueInstance.authorityCode || '';
//   const context = thisVueInstance.context || {};
//   const hasPermit = thisVueInstance.$mpHasPermit || (() => true);

//   let isShow = true;
//   if (typeof showCondition === 'string') {
//     const isTempArr = showCondition.match(/\{\{[\s\S]*\}\}/g);
//     if (isTempArr && isTempArr.length > 0) {
//       // 2.0.2版本新增: 对模板字符串进行处理
//       const templateAnalyzer = new TemplateAnalyzer(showCondition, '{{', '}}');
//       const templateAnalyzerRes = templateAnalyzer.result(context);
//       isShow = typeof templateAnalyzerRes === 'boolean'
//         ? templateAnalyzerRes
//         : scriptEngine.runExpression(showCondition, thisVueInstance, context);
//     } else {
//       isShow = scriptEngine.runExpression(showCondition, thisVueInstance, context);
//     }
//     isShow = scriptEngine.runExpression(showCondition, thisVueInstance, context);
//   } else if (typeof showCondition === 'boolean') {
//     isShow = showCondition;
//   }
//   let isHasPermit = true;
//   if (authCode && hasPermit) {
//     isHasPermit = hasPermit.call(thisVueInstance, authCode);
//   }

//   // 如果没有权限，则元素不会渲染出来；如果有权限但是条件判断不显示，则元素会渲染出来，但是display: none;
//   return {
//     isRender: isHasPermit,
//     isShow,
//     noRenderWhenNoShow: thisVueInstance.noRenderWhenNoShow,
//   };
// };
