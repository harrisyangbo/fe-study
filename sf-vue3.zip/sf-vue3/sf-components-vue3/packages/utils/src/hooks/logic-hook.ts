import registerHandle from './component-register';
import logicCallMixin from './logic-call';
import { ref, onMounted, watch, getCurrentInstance } from 'vue';
export default {
  commonLogicProps: {
    next: {
      type: String,
      default: '',
    },
  },
  setup(props) {
    const mpNext = ref('');
    const mpCurrentContext = ref({});
    const { mpRoot, logicCall } = logicCallMixin.setup();
    const interfaces: any = getCurrentInstance();
    const mpUpdateNext = (newNext) => {
      if (newNext) mpNext.value = newNext;
    };
    const mpRun = (prevResult) => {
      const onRun = interfaces?.ctx?.$options?.onRun; // 组件内部方法
      if (onRun && typeof onRun === 'function') {
        onRun.call(interfaces, prevResult, async (currentResult) => {
          if (mpNext.value) {
            await logicCall(mpNext.value, mpCurrentContext, currentResult);
          }
        });
      }
    };
    watch(() => props.next, (val) => {
      mpNext.value = val;
    });
    onMounted(() => {
      registerHandle(props.componentId);
    });
    return {
      mpRoot,
      logicCall,
      mpRun,
      mpUpdateNext,
      mpCurrentContext,
    };
  },
};
