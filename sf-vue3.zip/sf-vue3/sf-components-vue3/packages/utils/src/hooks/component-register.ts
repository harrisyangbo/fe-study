import { inject, nextTick, onBeforeUnmount } from 'vue';

export default function (componentId: string) {
  const mpRegister: any = inject('mpRegister', null);
  const mpSyncStatus: any = inject('mpSyncStatus', null);
  const mpUnRegister: any = inject('mpUnRegister', null);
  if (mpRegister) {
    mpRegister(componentId);
  }
  const mpNoticeReady = () => {
    nextTick(() => {
      mpSyncStatus(componentId, {
        $ready: true,
      });
    });
  };
  onBeforeUnmount(() => {
    mpUnRegister(componentId);
  });
  return {
    mpNoticeReady,
  };
}
