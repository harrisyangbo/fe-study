import { Src, FindMethod, MapMethod } from './interface';

function findRecursive(obj: Src, fn: FindMethod, childrenKey: string): Src {
  if (fn(obj)) return obj;
  if (obj[childrenKey]) {
    for (const child of obj[childrenKey]) {
      const childrenResult = findRecursive(child, fn, childrenKey);
      if (childrenResult) return childrenResult;
    }
  }
  return {};
}

let pathList: Src[] = [];
function findPathRecursive(obj: Src, fn: FindMethod, childrenKey: string): Src[] | null {
  pathList.push(obj);
  if (fn(obj)) return pathList;
  if (obj[childrenKey]) {
    for (const child of obj[childrenKey]) {
      const childrenResult = findPathRecursive(child, fn, childrenKey);
      if (childrenResult) return childrenResult;
    }
    pathList.pop();
  } else {
    pathList.pop();
  }
  return null;
}

let flattenList: Src[] = [];
function flattenRecursive(obj: Src, childrenKey: string): Src[] {
  flattenList.push(obj);
  if (obj[childrenKey]) {
    for (const child of obj[childrenKey]) {
      flattenRecursive(child, childrenKey);
    }
  }
  return flattenList;
}


function mapRecursive(obj: Src, index: number, fn: MapMethod, childrenKey: string): Src {
  const newItem = { ...fn(obj, index) };
  if (obj[childrenKey]) {
    newItem[childrenKey] = obj[childrenKey]
      .map((child: Src, tIndex: number) => mapRecursive(child, tIndex, fn, childrenKey));
  }
  return newItem;
}

function clearPathList(): void {
  pathList = [];
}

function clearFlattenList(): void {
  flattenList = [];
}

export {
  findRecursive,
  findPathRecursive,
  flattenRecursive,
  clearPathList,
  clearFlattenList,
  mapRecursive,
};
