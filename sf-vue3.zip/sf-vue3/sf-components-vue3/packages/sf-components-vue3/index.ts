import SfInput from '../components/sf-input';
import SfInteraction from '../components/sf-interaction';
import SfTable from '../components/sf-table';
import { SfLogicJS, SfLogicAjax } from '../components/logic';
import type { App } from 'vue';
// import 'element-plus/dist/index.css';

const components = [SfInput, SfInteraction, SfTable];

const install = (app: App) => {
  components.forEach(comp => app.use(comp));
};
export default {
  install,
};

export * from '@sf-components-vue3/components';
export const typeComponents = {
  text: SfInput,
  dropdown: 'el-select',
  time: 'el-time-picker',
  calendar: 'el-date-picker',
  checkbox: 'el-checkbox',
  radio: 'el-radio',
  switch: 'el-switch',
  hidden: 'div',
  table: SfTable,
  interaction: SfInteraction,
  ajax: SfLogicAjax,
  js: SfLogicJS,
  row: 'el-row',
  col: 'el-col',
};
