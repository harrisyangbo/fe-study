<template>
	<div :class="['sf-input', uiConfig.className]">
		<span
      :class="['label', required ? 'sf-required' : '' ]"
      :title="label"
      :style="{ width: uiConfig.labelWidth}"
      v-if="label !== ''"
    >{{ label }}</span>
    <span
      v-if="!readOnly && mode === 'normal'"
      :style="{ position: 'relative', 'flex-grow': uiConfig.flexGrow }"
    >
      <el-input
        v-if="!uri"
        :placeholder="placeholder || '请输入'"
        :clearable="clearable"
        :model-value="modelValue"
        @input="handleInput"
        @blur="inputBlur"
        @focus="inputFocus"
        @clear="clearHandle"
        :disabled="disabled"
      />
      <el-autocomplete
        v-else
        :model-value="modelValue"
        @input="handleInput"
        @blur="inputBlur"
        @focus="inputFocus"
        :disabled="disabled"
        :fetch-suggestions="querySearchAsync"
        :placeholder="placeholder || '请输入'"
      />
    </span>
	</div>
</template>

<script lang="ts">
import { computed, defineComponent, ref, onMounted } from 'vue';
import { ElInput, ElAutocomplete } from 'element-plus';
import { sfInputProps } from './sf-input-common';
import { UPDATE_MODEL_EVENT, QUERY_SEARCH } from '../../../utils/src/common/constants';
import registerHandle from '../../../utils/src/hooks/component-register';
export default defineComponent({
  name: 'SfInput',
  props: sfInputProps,
  components: {
    ElInput,
    ElAutocomplete,
  },
  emits: [
    UPDATE_MODEL_EVENT,
    QUERY_SEARCH,
  ],
  onRun() {
    console.log(111);
  },
  setup(props, ctx) {
    const uiConfig = computed(() => props.uiConfig);
    const readOnly = computed(() => props.readOnly);
    const disabled = computed(() => props.disabled);
    const label = computed(() => props.label);
    const placeholder = computed(() => props.placeholder);
    const mode = computed(() => props.mode);
    const required = computed(() => props.required);
    const clearable = computed(() => props.clearable);
    const uri = computed(() => props.uri);
    // let validateError = ref(false); // 校验是否错误
    const inputVal = ref('');
    const { mpNoticeReady } = registerHandle(props.componentId);
    const querySearchAsync = (queryString, cb) => {
      try {
        if (props.uri) {
          ctx.emit(QUERY_SEARCH, {
            uri: props.uri,
            inputContent: queryString,
            returnMatchResult: cb,
          });
        }
      } catch (err: any) {
        throw new Error(err);
      }
    };
    const handleInput = (val) => {
      ctx.emit(UPDATE_MODEL_EVENT, val);
    };
    const inputBlur = () => {

    };
    const inputFocus = () => {

    };
    const clearHandle = () => {
      ctx.emit(UPDATE_MODEL_EVENT, '');
    };
    onMounted(() => {
      // inputBlurRules.value = rules.value.filter((rule) => {
      //   if (rule.required) {
      //     required.value = true;
      //   }
      //   return rule.triggempNoticeReadyr === 'blur';
      // });
      mpNoticeReady();
    });
    return {
      inputVal,
      uiConfig,
      readOnly,
      disabled,
      label,
      placeholder,
      mode,
      required,
      clearable,
      uri,
      querySearchAsync,
      handleInput,
      inputBlur,
      inputFocus,
      clearHandle,
    };
  },
});
</script>
