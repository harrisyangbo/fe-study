// 组件的props 及 公共方法
import type { ExtractPropTypes } from 'vue';
interface UiConfig {
  className?: string;
  labelWidth?: string;
  flexGrow?: number;
}
export const sfInputProps = {
  modelValue: {
    type: String,
    default: '',
  },
  componentId: {
    type: String,
    default: '',
  },
  readOnly: {
    type: Boolean,
    default: false,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  label: {
    type: String,
    default: '输入框',
  },
  placeholder: {
    type: String,
    default: '请输入内容',
  },
  uri: {
    type: String,
    default: '',
  },
  clearable: {
    type: Boolean,
    default: false,
  },
  rules: {
    type: Array,
    default: () => [],
  },
  required: {
    type: Boolean,
    default: false,
  },
  mode: {
    type: String,
    default: 'normal',
  },
  uiConfig: {
    type: Object,
    default: (): UiConfig => ({}),
  },
} as const;

export type SfInputProps = ExtractPropTypes<typeof sfInputProps>;
