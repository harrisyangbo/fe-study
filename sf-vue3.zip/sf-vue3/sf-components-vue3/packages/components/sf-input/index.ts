import input from './src/sf-input.vue';
import { withInstall } from '../../utils/src/with-install';
const SfInput = withInstall(input);
export {
  SfInput,
};
export default SfInput;
