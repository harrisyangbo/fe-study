<script lang="ts">
import { defineComponent } from 'vue';
import { typer } from '@tencent/sailfish-utils';
import { logicHook } from '../../../utils/src/hooks/index';
import scriptEngine from '../../../utils/src/common/sf-eval';
export default defineComponent({
  name: 'SflogicJS',
  props: {
    script: {
      type: String,
      default: '',
    },
    componentId: {
      type: String,
      default: '',
    },
    ...logicHook.commonLogicProps,
  },
  setup(props) {
    const { mpUpdateNext, mpCurrentContext } = logicHook.setup(props);
    return {
      mpUpdateNext,
      mpCurrentContext,
    };
  },
  onRun(prevResult, next) {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const current: any = this;
    if (!typer.isNullOrUndefined(current.props.script) && !typer.isStringEmpty(current.props.script)) {
      // 定义script中的函数代码执行结果的回调函数，不管script中的函数是同步执行还是异步执行，确保resultCallback只执行一次
      console.log(prevResult);
      console.log(next);
      let isRun = false;
      const resultCallback = (result: {
        [key: string]: any
      } = {}) => {
        if (isRun) {
          return;
        }
        isRun = true;
        current.ctx.mpUpdateNext(result.next);
        next(result.params);
      };

      const result = scriptEngine
        .runFunctionWithoutSandbox(
          current.ctx.script,
          current.ctx, current.ctx.mpCurrentContext,
          prevResult, resultCallback,
        );
      if (!typer.isNullOrUndefined(result)) {
        resultCallback(result);
      }
    }
  },
  render() {},
});
</script>
