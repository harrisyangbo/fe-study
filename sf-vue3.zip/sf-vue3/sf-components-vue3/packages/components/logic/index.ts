import logicAjax from './src/sf-logic-ajax.vue';
import logicJS from './src/sf-logic-js.vue';
import { withInstall } from '../../utils/src/with-install';
const SfLogicAjax = withInstall(logicAjax);
const SfLogicJS = withInstall(logicJS);
export {
  SfLogicAjax,
  SfLogicJS,
};
