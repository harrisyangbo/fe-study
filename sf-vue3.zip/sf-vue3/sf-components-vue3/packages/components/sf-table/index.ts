import table from './src/sf-table.vue';
import { withInstall } from '../../utils/src/with-install';
const SfTable = withInstall(table);
export {
  SfTable,
};
export default SfTable;
