<script lang="ts">
import { computed, defineComponent, h, watch } from 'vue';
import { commonTableColumnProps } from './common-table';
import { ElTableColumn } from 'element-plus';
export default defineComponent({
  name: 'CommonTableColumn',
  props: commonTableColumnProps,
  components: {
    ElTableColumn,
  },
  setup(props) {
    const column = computed(() => props.column) as {
      [key: string]: any
    };
    watch(() => props.column, (val) => {
      console.log('..........');
      console.log(val);
    });
    const getSlots = computed(() => props.getSlots) as any;
    const baseColumn = (prop) => {
      if (!prop.type) {
        // const slots = getSlots ? getSlots({
        //   slotName: prop.slotName,
        //   headerSlotName: prop.headerSlotName,
        // }) : null;
        // 组件或自定义渲染内容
        const renderWithComponent = (scope) => {
          if (prop.component instanceof Function) {
            return prop.component(scope)(h, this);
          }
          return prop.component;
        };
        // 默认内容
        const renderWithProp = (scope, key) => scope.row[key];
        // 没有传入slotName默认处理
        const  handleDefaultRender = (scope) => {
          if (prop.prop) {
            return renderWithProp(scope, prop.prop);
          }
          return renderWithComponent(scope);
        };
        // vue-jsx中slot的实现方法
        const scopedSlots = {
          default: (scope) => {
            handleDefaultRender(scope);
          },
          // header: scope => (slots.header ? slots.header(scope)
          //   : prop.label),
        };
        console.log('____________');
        console.log({ ...prop });
        return h(ElTableColumn, { ...prop, ...scopedSlots });
      }
    };
    const columnTree = () => {
      // 构建表格的column
      if (column.children) {
        const childrenEles = column.children.map(item => baseColumn(item));
        return h(ElTableColumn, { props: column }, childrenEles);
      }
      return baseColumn(column);
      // return h(ElTableColumn, {
      //   prop: 'data_id',
      //   label: '列头-编号',
      // });
    };
    return {
      column,
      getSlots,
      columnTree,
    };
  },
  render() {
    return this.columnTree();
  },
});
</script>
