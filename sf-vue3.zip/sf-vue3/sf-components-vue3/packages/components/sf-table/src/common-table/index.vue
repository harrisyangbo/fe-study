<template>
	<div class="common-table">
    <!-- 表格 TODO： v-loading="tableAttrsThisFixed.loading || false" -->
    <el-table
      v-bind="tableAttrsThisFixed"
      v-on="tableEventsThisFixed"
      v-if="columnsThisFixed && columnsThisFixed.length > 0"
      ref="table"
    >
      <!-- columns -->
      <!-- <BaseColumn v-for="(item, index) in columnsThisFixed" :key="index" :data="item" /> -->
      <el-table-column v-for="(item, index) in columnsThisFixed" :key="index" v-bind="{
        ...item,
      }">
        <template #default="scope">
          <base-cell :attrs="item" :scope="scope" />
        </template>
      </el-table-column>

      <!-- <template v-for="(column, index) in columnsThisFixed">
        <CommonTableColumn
          :getSlots="getSlots"
          :column="column"
        >
          <template
            v-for="headerSlotName in slotList.header"
            #[`${headerSlotName}-header`]="scope"
          >
            <slot
              :name="`${headerSlotName}-header`"
              v-bind="scope"
            />
          </template>
          <template
            v-for="slotName in slotList.default"
            #[slotName]="scope"
          >
            <slot
              :name="slotName"
              v-bind="scope"
            />
          </template>
        </CommonTableColumn>
      </template> -->

      <!-- table 尾部slot -->
      <!-- <template slot="append">
        <slot name="append" />
      </template> -->
    </el-table>

    <!-- 表格和分页器间可放入其他元素 -->
    <slot name="middle" />

    <!-- 分页器 -->
    <!-- <el-pagination
      v-if="!disablePagination"
      v-bind="mergedPaginationAttrs.datas"
      v-on="paginationEventsThisFixed"
    /> -->
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, onMounted, watch, computed, getCurrentInstance } from 'vue';
import { ElTable, ElPagination, ElTableColumn } from 'element-plus';
import type { Ref } from 'vue';
import { tableProps } from './common-table';
// import CommonTableColumn from './common-table-column.vue';
// import BaseColumn from './base-column.vue';
import BaseCell from './base-cell.vue';
import tree from '../../../../utils/src/tree-shredder/tree';
export default defineComponent({
  props: tableProps,
  components: {
    // CommonTableColumn,
    ElTable,
    ElPagination,
    ElTableColumn,
    BaseCell,
    // BaseColumn,
  },
  setup(props, ctx) {
    // eslint-disable-next-line @typescript-eslint/naming-convention
    const _this = getCurrentInstance();
    // 代码逻辑使用，停止所有watcher以避免死循环
    const stopWatching = ref(false);
    // 合并分页器属性和默认属性
    const mergedPaginationAttrs = reactive({
      datas: {
        layout: 'prev, pager, next',
        total: 1,
        currentPage: 0,
      },
    });
    const table: Ref< HTMLElement | null > = ref(null);
    // 将传入值为函数的属性的this绑定到父组件
    // 默认绑定在CommonTable组件上
    // 如果这个绑定不符合您当前的需求，可以自行在外层bind，然后在传入的函数名前添加 NOFIXTHIS_ 前缀，这样组件不会再自动修复绑定
    const fixThis  = (obj) => {
      if (!(obj instanceof Object)) return obj;
      if (!_this) return obj;
      const result = {};
      Object.keys(obj).forEach((key) => {
        if (obj[key] instanceof Function) {
          if (key.includes('NOFIXTHIS_')) {
            result[key.substring(key.indexOf('_') + 1)] = obj[key];
          } else {
            result[key] = obj[key].bind(_this.parent);
          }
        } else if (obj[key] instanceof Array) {
          result[key] = obj[key].map(item => fixThis(item));
        } else if (obj[key] instanceof Object) {
          result[key] = fixThis(obj[key]);
        } else {
          result[key] = obj[key];
        }
      });
      return result;
    };
    const getSlots = ({ slotName, headerSlotName }) => ({
      default: ctx.slots[slotName],
      header: ctx.slots[headerSlotName],
    });
    const tableAttrsThisFixed = computed(() => fixThis(props.tableAttrs));
    const tableEventsThisFixed = computed(() => fixThis(props.tableEvents));
    const columnsThisFixed = computed(() => props.columns.map(column => fixThis(column)));
    const paginationEventsThisFixed = computed(() => fixThis(props.paginationAttrs));
    const slotList = computed(() => {
      if (props.columns && props.columns.length > 0) {
        const forest = props.columns.map(column => tree(column as {
          [key: string]: any
        })).map(item => item.flatten())
          .reduce((prev, next) => prev.concat(next), []);
        return {
          default: forest.filter(item => item.src().slotName).map(item => item.src().slotName),
          header: forest.filter(item => item.src().headerSlotName).map(item => item.src().headerSlotName),
        };
      }
    });
    // 父组件同步给子组件分页器配置
    watch(() => props.paginationAttrs, (val) => {
      console.log('=======props.paginationAttrs======');
      console.log(mergedPaginationAttrs.datas);
      if (!stopWatching) {
        const mergedOld = mergedPaginationAttrs.datas;
        mergedPaginationAttrs.datas = Object.assign({}, mergedOld, val);
      }
    }, { deep: true });
    watch(() => mergedPaginationAttrs.datas.currentPage, (val) => {
      stopWatching.value = true;
      ctx.emit('', {
        ...mergedPaginationAttrs.datas,
        currentPage: val,
      });
      stopWatching.value = false;
    });
    onMounted(() => {
      console.log('=====table $refs====');
      console.log(table.value);
    });
    return {
      table,
      tableAttrsThisFixed,
      tableEventsThisFixed,
      columnsThisFixed,
      paginationEventsThisFixed,
      slotList,
      mergedPaginationAttrs,
      getSlots,
      fixThis,
    };
  },
});
</script>

<style>

</style>
