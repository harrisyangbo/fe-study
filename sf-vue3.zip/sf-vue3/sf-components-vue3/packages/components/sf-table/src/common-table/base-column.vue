<script lang="ts">
import { computed, defineComponent, h } from 'vue';
import { baseColumnProps } from './common-table';
import { ElTableColumn } from 'element-plus';
export default defineComponent({
  name: 'BaseColumn',
  props: baseColumnProps,
  components: {
    ElTableColumn,
  },
  setup(props) {
    const data = computed(() => {
      console.log('________________');
      console.log(props.data);
      return props.data;
    }) as {
      [key: string]: any
    };
    return {
      data,
    };
  },
  render() {
    // const datas = this.data;
    // if (!datas?.type) {
    //   const slots = this.getSlots({
    //     slotName: datas.slotName,
    //     headerSlotName: datas.headerSlotName,
    //   });
    //   // 组件或自定义渲染内容
    //   const renderWithComponent = (scope) => {
    //     if (datas.component instanceof Function) {
    //       return datas.component(scope)(h, this);
    //     }
    //     return datas.component;
    //   };
    //   // 默认内容
    //   const renderWithProp = (scope, key) => scope.row[key];
    //   // 没有传入slotName默认处理
    //   const  handleDefaultRender = (scope) => {
    //     if (datas.prop) {
    //       return renderWithProp(scope, datas.prop);
    //     }
    //     return renderWithComponent(scope);
    //   };
    //   // vue-jsx中slot的实现方法
    //   const scopedSlots = {
    //     default: (scope) => {
    //       if (slots.default) {
    //         console.log(slots.default(scope), '&&&');
    //         return (slots.default ? slots.default(scope)
    //           : handleDefaultRender(scope));
    //       }
    //     },
    //     header: scope => (slots.header ? slots.header(scope)
    //       : datas.label),
    //   };
    //   return h('el-table-column', { props: { ...datas }, scopedSlots: { ...scopedSlots } });
    // }
    const scopedSlots = {
      default: (scope) => {
        console.log('.............');
        console.log(this.data);
        console.log(scope);
        return h('span', {}, '1111');
      },
      header: (scope) => {
        console.log('.......header......');
        console.log(scope);
      },
    };
    return h(ElTableColumn, { ...this.data, slots: {
      ...scopedSlots,
    } });
  },
});
</script>
