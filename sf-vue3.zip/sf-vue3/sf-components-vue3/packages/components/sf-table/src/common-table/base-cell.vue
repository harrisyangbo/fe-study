<script lang="ts">
import { defineComponent, h } from 'vue';
// import { renderField } from '../sf-table-common';
import Raw from '../fields/raw.vue';
import Timespan from '../fields/timespan.vue';
import Datetime from '../fields/datetime.vue';
import Money from '../fields/money.vue';
import Thumbnail from '../fields/thumbnail.vue';
import Audio from '../fields/audio.vue';
import InterAction from '../fields/interaction.vue';
import Divider from '../fields/divider.vue';
import { decodeHTML } from '../../../../utils/src/common/html-escape';
const compMap = {
  raw: Raw,
  timespan: Timespan,
  datetime: Datetime,
  money: Money,
  thumbnail: Thumbnail,
  audio: Audio,
  interaction: InterAction,
  divider: Divider,
};
export default defineComponent({
  name: 'BaseCell',
  component: {
    Raw,
    Timespan,
    Datetime,
    Money,
    Thumbnail,
    Audio,
    InterAction,
    Divider,
  },
  props: {
    attrs: {
      type: Object,
      default: () => {},
    },
    scope: {
      type: Object,
      default: () => {},
    },
  },
  setup(props) {
    // const attrs = computed(() => props.attrs);
    const makeField = (type, value, field) => {
      if (compMap[type]) {
        return h(compMap[type], {
          value,
          field,
        });
      }
      return h('span', {}, props?.scope?.row ? props?.scope?.row[field.key] : '');
    };
    const makeFields = (fields, value) => {
      const fieldMap = fields.map((item) => {
        if (item.type === 'divider') {
          return h('span', { innerHTML: decodeHTML(item.text) });
        }
        return makeField(item.type, value, item);
      });
      // 单元格内多 field 内容
      return h('div', {
        style: {
          // display: disableOverflowTooltip ? 'block' : 'flex',
          alignItems: 'center',
          flexWrap: 'nowrap',
          // whiteSpace: disableOverflowTooltip ? 'wrap' : 'nowrap',
        },
        className: 'cell-fields',
      }, fieldMap);
    };
    const cellVNode = (nodeProps) => {
      const { type, value, field } = nodeProps;
      if (!nodeProps) {
        console.warn('makeField没有传入节点属性!');
        return h('span', {}, '');
      }
      if (nodeProps.field?.fields) {
        return makeFields(nodeProps.field.fields, value);
      }
      return makeField(type, value, field);
    };
    return {
      makeField,
      cellVNode,
    };
  },
  render() {
    // console.log(this.$props.rowData);
    // const { key } = this.$props.attrs;
    // console.log('>>>>>>>>>>>>');
    // console.log(renderField(this.$props.scope, this.$props.attrs, this));
    // const innerHtml = key ? this.$props.scope.row[key] : '';
    const { type, key } = this.$props.attrs;
    const nodeProps = {
      value: this.$props.scope.row[key],
      field: this.$props.attrs,
      row: this.$props.scope.row,
      rowIndex: this.$props.scope.$index,
      context: this,
      type,
    };
    // if (compMap[type]) {
    //   return h(compMap[type], {
    //     value: nodeProps.value,
    //     field: nodeProps.field,
    //   });
    // }
    return this.cellVNode(nodeProps);
    // return h('span', {}, this.$props.scope.row[key]);
  },
});
</script>
