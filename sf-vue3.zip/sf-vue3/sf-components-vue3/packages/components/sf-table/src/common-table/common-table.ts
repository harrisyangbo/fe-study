// 组件的props 及 公共方法
import type { ExtractPropTypes } from 'vue';
import SfAjaxLogic from '../../../logic/src/sf-logic-ajax.vue';
import SfJsLogic from '../../../logic/src/sf-logic-js.vue';
export const tableProps = {
  // 表格配置
  tableAttrs: {
    type: Object,
    default() {
      return {};
    },
  },
  // 表格事件
  tableEvents: {
    type: Object,
    default() {
      return {};
    },
  },
  // 表格栏配置
  columns: {
    type: Array,
    default() {
      return [];
    },
  },
  // 禁用分页器
  disablePagination: {
    type: Boolean,
    default: false,
  },
  // 分页器配置
  paginationAttrs: {
    type: Object,
    default() {
      return {};
    },
  },
  // 分页器事件
  paginationEvents: {
    type: Object,
    default() {
      return {};
    },
  },
} as const;
export const commonTableColumnProps = {
  column: {
    type: Object,
    default: () => null,
  },
  getSlots: {
    type: Function,
    default: () => null,
  },
};
export const baseColumnProps = {
  data: {
    type: Object,
    default: () => {},
  },
  getSlots: {
    type: Function,
    default: () => null,
  },
} as const;
export type TableProps = ExtractPropTypes<typeof tableProps>;
export type CommonTableColumnProps = ExtractPropTypes<typeof commonTableColumnProps>;
export type BaseColumn = ExtractPropTypes<typeof baseColumnProps>;
export const LOGIC_FIELDS = {
  request: SfAjaxLogic,
  js: SfJsLogic,
};
