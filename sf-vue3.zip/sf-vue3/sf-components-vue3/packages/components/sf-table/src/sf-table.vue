<template>
  <div class="sf-table">
    <CommonTable
      style="width: 100%"
      :table-attrs="tableAttrs"
      :table-events="tableEvents"
      :columns="columnsFormatted"
      :pagination-attrs.sync="paginationAttrs"
      :pagination-events="paginationEvents"
      ref="cTable"
    >
      <template #middle>
        <div style="height: 10px" />
      </template>
    </CommonTable>
    <!-- <div
      class="viewer"
      v-viewer="{toolbar: false}"
      v-show="false"
    >
      <img
        v-for="src in currentViewImage"
        :src="src"
        :key="src"
      >
    </div> -->
  </div>
</template>

<script lang="ts">
import { ref, watch, computed, defineComponent, onMounted, reactive, getCurrentInstance } from 'vue';
import { componentRegister } from '../../../utils/src/hooks/index';
import { sfTableProps, EL_TABLE_EVENTS, EL_PAGINATION_EVENTS, ORDER_STR } from './sf-table-common';
import CommonTable from './common-table/index.vue';
// import { decodeHTML } from '../../../utils/src/common/html-escape';
const SELECTION_WIDTH = '30';
export default defineComponent({
  name: 'SfTable',
  props: sfTableProps,
  components: {
    CommonTable,
  },
  setup(props, ctx) {
    const { mpNoticeReady } = componentRegister(props.componentId);
    const currentInterface =  getCurrentInstance();
    // eslint-disable-next-line @typescript-eslint/naming-convention
    const _this = currentInterface?.appContext.config.globalProperties;
    const currentViewImage = reactive([]);
    const currentPage = computed(() => props.currentPage);
    const total = computed(() => props.total);
    const pageSize = computed(() => props.pageSize);
    const paginationAttrs = reactive({
      layout: 'total, sizes, prev, pager, next, jumper',
      currentPage,
      total,
      pageSize,
      pageSizes: [10, 15, 20, 25, 30],
    });
    const stopWatching = ref(false);
    const tableAttrs = computed(() => ({
      stripe: true,
      'header-cell-class-name': 'dh-table-header',
      data: props.tableData,
      loading: props.loading,
    }));
    const tableEvents = computed(() => EL_TABLE_EVENTS.reduce((newObj, key) => ({
      ...newObj,
      [`NOFIXTHIS_${key}`]: function (event) {
        let tEvent = event;
        switch (key) {
          // 改造sort-change事件使之能配合项目
          // 对复合项目只能同时有一个数据处于sortable状态
          case 'sort-change':
            // 以下变量只在该case里使用
            /* eslint-disable no-case-declarations */
            const realColumn: any = props.columns.find((item: any) => item.label === event.column.label);
            const field = realColumn.fields ? realColumn.fields.find(item => item.sortable) : realColumn.field;
            /* eslint-enable no-case-declarations */
            tEvent = { ...event, field };
            tEvent.order = ORDER_STR[tEvent.order] || null;
            break;
        }
        ctx.emit(key, tEvent);
      }.bind(_this),
    }), {}));
    const paginationEvents = computed(() => EL_PAGINATION_EVENTS.reduce((newObj, key) => ({
      ...newObj,
      [`NOFIXTHIS_${key}`]: function (event) {
        // const tEvent = event;
        switch (key) {
          case 'size-change':
            // 没有直接修改，只是传递了函数
            /* eslint-disable vue/no-side-effects-in-computed-properties */
            paginationAttrs.currentPage = 1;
            paginationAttrs.pageSize = event;
            /* eslint-enable vue/no-side-effects-in-computed-properties */
            break;
        }
        // TODO: 增加分页组件
        // 由于pagination和table都有current-change事件，为避免冲突改为page-change
        // this.$nextTick(() => {
        //   this.$emit(key === 'current-change' ? 'page-change' : key, tEvent);
        // });
      }.bind(this),
    }), {}));
    // 表格列处理
    const columnsFormatted = computed(() => {
      const columnsList = props.columns.map(column => makeCol(column));
      return [
        ...(props.selection ? [{ type: 'selection', width: SELECTION_WIDTH }] : []),
        ...columnsList,
      ];
    });
    // 构建单元格单field的vNode
    const makeField = (field) => {
      const result = {
        ...field,
      };
      // 是否可排序
      result.sortable = field.sortable ? 'custom' : false;
      // result.component = scope => c(scope, field, {
      //   ...props.context,
      // });
      if (field.key) {
        result.prop = field.key;
      }
      return result;
    };
    // 构建单元格多field的vNode
    // const makeFields = (fields) => {
    //   // 需要考虑配置单元格内的分隔符情况
    //   const result = {};
    //   // 是否可排序
    //   result.sortable = fields.some(field => field.sortable) ? 'custom' : false;
    //   result.component = () => h('div', {
    //     style: {
    //       display: disableOverflowTooltip ? 'block' : 'flex',
    //       alignItems: 'center',
    //       flexWrap: 'nowrap',
    //       whiteSpace: disableOverflowTooltip ? 'wrap' : 'nowrap',
    //     },
    //   }, fields.map((field) => {
    //     if (typeof field === 'string') {
    //       return h('span', { domProps: { innerHTML: decodeHTML(field) } });
    //     }
    //     return renderField(scope, field, {
    //       ...props.context,
    //     });
    //   }));
    // };
    // 构建表格列
    const makeCol = (column) => {
      let result: {
        [key: string]: any
      } = {};
      // 公共配置
      result.label = column.label;
      // 宽度
      if (column.width) result.width = column.width;
      // 是否显示tooltip
      result.showOverflowTooltip = !column.disableOverflowTooltip;
      // 是否固定当前列
      result.fixed = column.fixed;
      result['class-name'] = column.className;
      result['label-class-name'] = column.labelClassName;
      if (column.fields) {
        result.fields = column.fields;
      }
      // 组件配置
      if (column.children) {
        result.children = column.children.map(item => ({
          ...makeCol(item),
        }));
      } else if (column.field) {
        result = { ...result, ...makeField(column.field) };
      }
      // else if (column.fields) {
      //   result = { ...result, ...makeFields(column.fields, column.disableOverflowTooltip) };

      // }
      return result;
    };
    watch(() => paginationAttrs, (val) => {
      stopWatching.value = true;
      ctx.emit('update:currentPage', val.currentPage);
      ctx.emit('update:total', val.total);
      ctx.emit('update:pageSize', val.pageSize);
      stopWatching.value = false;
    });
    onMounted(() => {
      mpNoticeReady();
    });
    return {
      tableAttrs,
      tableEvents,
      currentViewImage,
      makeCol,
      columnsFormatted,
      paginationEvents,
      paginationAttrs,
    };
  },
});
</script>

<style>

</style>
