<template>
  <span
    class="table-item-datetime"
    :title="timeValue"
  >
    {{ timeValue }}
  </span>
</template>

<script>
import { DateTime } from 'luxon';
import { defineComponent, computed } from 'vue';
export default defineComponent({
  props: {
    value: {
      type: [String, Number],
      default: 0,
    },
    field: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  setup(props) {
    const timeValue = computed(() => {
      if (!props.value) return '';
      const { value, field } = props;
      return DateTime.fromSeconds(value).toFormat(field.format || 'yyyy-MM-dd HH:mm:ss');
    });
    return {
      timeValue,
    };
  },
});
</script>
