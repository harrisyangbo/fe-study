<template>
  <span
    class="table-item-time-span"
    :title="timeValue"
  >
    {{ timeValue }}
  </span>
</template>

<script>
import { Duration } from 'luxon';
import { defineComponent, computed } from 'vue';
export default defineComponent({
  props: {
    value: {
      type: Number,
      default: 0,
    },
    field: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  setup() {
    const timeValue = computed(() => {
      if (!props.value) return '';
      return Duration.fromMillis(Number(props.value) * 1000).toFormat(props.field?.format || 'h小时m分ss秒');
    });
    return {
      timeValue,
    };
  },
});
</script>
