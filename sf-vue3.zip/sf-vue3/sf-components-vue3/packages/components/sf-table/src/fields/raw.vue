<template>
  <span
    class="table-item-raw"
    :title="values"
  >
    {{ values }}
  </span>
</template>

<script>
import { defineComponent } from 'vue';
export default defineComponent({
  name: 'Raw',
  props: {
    value: {
      type: [String, Number],
      default: 0,
    },
  },
  setup(props) {
    // const values = computed(() => props.value);
    return {
      values: props.value,
    };
  },
});
</script>
