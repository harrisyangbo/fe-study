import Raw from './raw.vue';
import Timespan from './timespan.vue';
import Datetime from './datetime.vue';
import Money from './money.vue';
import Thumbnail from './thumbnail.vue';
import Audio from './audio.vue';
import InterAction from './interaction.vue';
import Divider from './divider.vue';
// 单元格组件集合
export const Fields = {
  raw: Raw,
  timespan: Timespan,
  datetime: Datetime,
  money: Money,
  thumbnail: Thumbnail,
  audio: Audio,
  interaction: InterAction,
  divider: Divider,
};

// 内置组件列表
export const FIELDS_LIST = [
  'raw',
  'timespan',
  'datetime',
  'money',
  'thumbnail',
  'audio',
  'interaction',
  'divider',
];
export const getTableFields = () => Fields;
