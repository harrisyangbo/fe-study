<template>
  <span
    class="table-item-money"
    :title="moneyValue"
  >
    {{ moneyValue }}
  </span>
</template>
<script>
import { defineComponent, computed } from 'vue';
export default defineComponent({
  props: {
    value: {
      type: Number,
      default: 0,
    },
  },
  setup(props) {
    const moneyValue = computed(() => props.value.toLocaleString('zh-cn', { style: 'currency', currency: 'CNY' }));
    return {
      moneyValue,
    };
  },
});
</script>
