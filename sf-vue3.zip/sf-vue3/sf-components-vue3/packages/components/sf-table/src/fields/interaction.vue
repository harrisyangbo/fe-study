<template>
  <span class="table-item-interaction">
    <SfInteraction
      v-bind="interactionProps"
      :render-link-button="false"
    />
  </span>
</template>

<script>
import SfInteraction from '../../../sf-interaction/src/sf-interaction.vue';
import { defineComponent, computed } from 'vue';
export default defineComponent({
  components: {
    SfInteraction,
  },
  props: {
    value: {
      type: [String, Number],
      default: 0,
    },
    field: {
      type: Object,
      default() {
        return {};
      },
    },
    row: {
      type: Object,
      default() {
        return {};
      },
    },
    rowIndex: {
      type: Number,
      default: 0,
    },
    context: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  setup(props) {
    const interactionProps = computed(() => ({
      label: props.field.label || '默认文案',
      componentId: props.field.componentId || '',
      actionName: props.field.action.name || '',
      renderLinkButton: props.field.action.renderLinkButton,
      main: props.field.main,
      logic: props.field.action.name || '',
      params: props.field.action.params,
    }));
    return {
      interactionProps,
    };
  },
});
</script>
