<template>
  <span class="table-item-audio">
    <audio
      controls="controls"
      controlsList="nodownload"
      ref="audio"
      preload="metadata"
    >
      <!-- 您的浏览器不支持播放音频 -->
      <source :src="value">
    </audio>

    <el-button
      class="btn-rate"
      v-if="field.showRate"
      @click="changeRate"
      round
    >
      x{{ rateList[curRateIndex] }}
    </el-button>
  </span>
</template>

<script>
import { ElButton } from 'element-plus';
import { defineComponent, ref } from 'vue';
const RATE_LIST = [1, 1.5, 2];
export default defineComponent({
  components: {
    ElButton,
  },
  props: {
    value: {
      type: [String, Number],
      default: 0,
    },
    field: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  setup() {
    const curRateIndex = ref(0);
    const audio = ref(null);
    // 更改播放速率
    const changeRate = () => {
      curRateIndex.value = curRateIndex.value + 1;
      if (curRateIndex.value >= RATE_LIST.length) curRateIndex.value = 0;
      if (audio.value) {
        audio.value.playbackRate = RATE_LIST[curRateIndex.value];
      }
    };
    return {
      rateList: RATE_LIST,
      curRateIndex: 0,
      changeRate,
      audio,
    };
  },
});
</script>

<style scoped>
.table-item-audio {
  display: flex;
  align-items: center;
}
.table-item-audio .btn-rate {
  width: 72px;
  margin-left: 8px;
}
</style>
