<template>
  <span
    class="table-item-divider"
    v-show="showDivider"
  >
    <span v-html="decodedText" />
  </span>
</template>

<script>
import { decodeHTML } from '../../../../utils/src/common/html-escape';
import { defineComponent, computed } from 'vue';
export default defineComponent({
  props: {
    field: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  setup(props) {
    const showDivider = ref(true);
    const decodedText = computed(() => decodeHTML(props?.field?.text));
    return {
      showDivider,
      decodedText,
    };
  },
});
</script>
