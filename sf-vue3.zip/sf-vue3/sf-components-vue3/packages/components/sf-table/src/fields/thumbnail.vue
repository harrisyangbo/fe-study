<template>
  <span class="table-item-thumbnail"></span>
</template>
<script lang="ts">
import { defineComponent, computed } from 'vue';
export default defineComponent({
  props: {
    value: {
      type: [String, Number],
      default: 0,
    },
    field: {
      type: Object,
      default: () => {},
    },
  } as any,
  setup(props, ctx) {
    const values = computed(() => props.value);
    const thumbStyle = computed(() => {
      const result: {
        [key: string]: any
      } = {};
      if (props.field?.height) {
        result.height = String(props.field.height);
        result.height += isNaN(Number(props.field.height)) ? '' : 'px';
      }
      if (props.field?.width) {
        result.width = String(props.field.width);
        result.width += isNaN(Number(props.field.width)) ? '' : 'px';
      }
      return result;
    });
    const handleImgClick = () => {
      ctx.emit('imageView', props.value);
    };
    return {
      thumbStyle,
      handleImgClick,
      values,
    };
  },
});
</script>

<style scoped>
.table-item-thumbnail .thumb {
  width: 100px;
  cursor: zoom-in;
}
</style>
