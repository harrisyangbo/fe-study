// 组件的props 及 公共方法
import { ExtractPropTypes, h } from 'vue';
import { getTableFields } from './fields/contants';
// import { checkAuth } from '../../hooks/authority';
export const sfTableProps = {
  componentId: {
    type: String,
    default: '',
  },
  tableData: {
    type: Array,
    default: () => [],
  },
  loading: {
    type: Boolean,
    default: false,
  },
  disablePagination: {
    type: Boolean,
    default: false,
  },
  selection: {
    type: Boolean,
    default: false,
  },
  currentPage: {
    type: Number,
    default: 1,
  },
  total: {
    type: Number,
    default: 0,
  },
  pageSize: {
    type: Number,
    default: 10,
  },
  columns: {
    type: Array,
    default: () => [],
  },
  context: {
    type: Object,
    default: () => {},
  },
  useCustomImageViewer: {
    type: Boolean,
    default: false,
  },
};

export type SfTableProps = ExtractPropTypes<typeof sfTableProps>;
// el-table原生事件列表
export const EL_TABLE_EVENTS = [
  'select',
  'select-all',
  'selection-change',
  'cell-mouse-enter',
  'cell-mouse-leave',
  'cell-click',
  'cell-dblclick',
  'row-click',
  'row-contextmenu',
  'row-dblclick',
  'header-click',
  'header-contextmenu',
  'sort-change',
  'filter-change',
  'current-change',
  'header-dragend',
  'expand-change',
];

// el-pagination原生事件列表
export const EL_PAGINATION_EVENTS = [
  'size-change',
  'current-change',
  'prev-click',
  'next-click',
];

// 排序类型
export const ORDER_STR = {
  ascending: 'asc',
  descending: 'desc',
};
// export const authField = (field, row, context, hasPermit) => {
//   let virtualComp = {
//     showCondition: field.showCondition,
//     authorityCode: field.authorityCode,
//     context: context,
//     hasPermit
//   };
//   return checkAuth(virtualComp);
/// },
// 构建单元格内组件vNode
const Fields = getTableFields();
export const renderField = (scope, field, context) => {
  // 构造props
  if (Fields[field.type]) {
    const fieldProps = {
      value: scope.row[field.key],
      field: { ...field },
      row: { ...scope.row },
      rowIndex: scope.$index,
      context,
    };
    return h(Fields[field], {
      ...fieldProps,
    });
  }
  return h('span', {}, scope.row[field.key]);
};
