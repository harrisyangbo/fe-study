import interaction from './src/sf-interaction.vue';
import { withInstall } from '../../utils/src/with-install';
const SfInteraction = withInstall(interaction);
export {
  SfInteraction,
};
export default SfInteraction;
