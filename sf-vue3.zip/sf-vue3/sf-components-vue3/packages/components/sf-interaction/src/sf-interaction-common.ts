// 组件的props 及 公共方法
import type { ExtractPropTypes } from 'vue';
export const sfInteractionProps = {
  componentId: {
    type: String,
    default: '',
  },
  label: {
    type: String,
    default: '',
  },
  renderLinkButton: {
    type: Boolean,
    default: false,
  },
  main: {
    type: Boolean,
    default: false,
  },
  logic: {
    type: String,
    default: '',
  },
  params: {
    type: Object,
    default: () => null,
  },
  context: {
    type: Object,
    default: () => ({}),
  },
  actionName: {
    type: String,
    default: '',
  },
  actionArgs: {
    type: Object,
    default: () => ({}),
  },
} as const;

export type SfInteractionProps = ExtractPropTypes<typeof sfInteractionProps>;
