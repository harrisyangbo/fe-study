<template>
	<div class="sf-interaction">
		<a
			:name="attrName"
			href="javascript:void(0);"
			v-if="isRenderLinkButton"
			@click="handleClick"
			:data-action-name="actionName"
			:data-action-args="actionArgsString"
		>
			<slot>{{ label }}</slot>
		</a>
		<el-button
			class="dh-interaction-button"
			:name="attrName"
			:type="buttonType"
			@click="handleClick"
			:data-action-name="actionName"
			:data-action-args="actionArgsString"
			v-else
		>
			<slot>{{ label }}</slot>
		</el-button>
	</div>
</template>

<script lang="ts">
import { defineComponent, computed, toRefs } from 'vue';
import { ElButton } from 'element-plus';
import { sfInteractionProps } from './sf-interaction-common';
import { logicHook } from '../../../utils/src/hooks/index';
export default defineComponent({
  name: 'SfInteraction',
  props: sfInteractionProps,
  components: {
    ElButton,
  },
  setup(props, ctx) {
    const {
      label,
      params,
      actionName,
    } = toRefs(props);
    const { logicCall } = logicHook.setup(props);
    const isRenderLinkButton = computed(() => props.renderLinkButton);
    const attrName = computed(() => {
      if (label.value) {
        return label.value;
      }
      if (ctx.slots.default && ctx.slots.default.length > 0) {
        return ctx.slots.default[0].text.trim();
      }
      return '';
    });
    const buttonType = computed(() => {
      if (isRenderLinkButton.value) {
        return 'text';
      } if (props.main) {
        return 'primary';
      }
      return '';
    });
    const actionArgsString = computed(() => JSON.stringify(props.actionArgs));
    const handleClick = () => {
      logicCall(props.logic, props.context, props.params ? props.params : undefined);
    };
    return {
      label,
      params,
      actionName,
      isRenderLinkButton,
      attrName,
      buttonType,
      actionArgsString,
      handleClick,
    };
  },
});
</script>

<style>

</style>
