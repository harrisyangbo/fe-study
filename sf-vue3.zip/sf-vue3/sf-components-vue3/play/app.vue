<template>
	<div class="play">----组件库组件测试----</div>
	<div>输入测试 {{inputA}}</div>
	<SfInput v-model="inputB"
		:uiConfig="{className: 'play-bb'}"
		:componentId="'vbbbbbbbbbb'"
		:label="'输入框2:'"></SfInput>
  <div>----------------------------------------------------</div>
  <TableTest />
</template>

<script>
import SfInput from '../packages/components/sf-input/src/sf-input.vue';
import TableTest from './table-test.vue';
import { ref, provide } from 'vue';
export default {
  components: { SfInput, TableTest },
  setup() {
    const inputA = ref('输入111');
    const inputB = ref('输入222');
    const mpRegister = (componentId) => {
      console.log('========mpRegister=======');
      console.log(componentId);
    };
    const mpSyncStatus = (componentId) => {
      console.log('========mpSyncStatus=======');
      console.log(componentId);
    };
    const mpUnRegister = (componentId) => {
      console.log('========mpUnRegister=======');
      console.log(componentId);
    };
    provide('mpRegister', mpRegister);
    provide('mpSyncStatus', mpSyncStatus);
    provide('mpUnRegister', mpUnRegister);
    return {
      inputA,
      inputB,
    };
  },
};
</script>

<style>

</style>
