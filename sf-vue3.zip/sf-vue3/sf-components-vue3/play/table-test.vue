<script>
import { defineComponent, h, ref } from 'vue';
import SfTable from '../packages/components/sf-table/src/sf-table.vue';
export default defineComponent({
  name: 'TableTest',
  components: {
    SfTable,
  },
  setup() {
    // 构造测试配置
    const propsMap = ref({
      type: 'component',
      id: 'tableData',
      keyName: 'dataList',
      name: 'SfTable',
      componentId: 'id11223344',
      columns: [
        {
          field: {
            type: 'raw',
            key: 'data_id',
            sortable: false,
          },
          label: '列头-编号',
        },
        {
          field: {
            type: 'link',
            key: 'doctor_name',
            uri: '/doctor/info/${row.id}',
            sortable: 'sortable',
          },
          label: '列头-医生姓名链接',
        },
        {
          field: {
            type: 'datetime',
            key: 'doctor_time',
            format: 'yyyy-MM-dd hh:mm:ss.S',
          },
          label: '列头-时间',
        },
        {
          field: {
            type: 'money',
            key: 'doctor_price',
          },
          label: '列头-金额',
        },
        // {
        //   field: {
        //     type: 'enum_text',
        //     key_name: 'doctor_name',
        //     options_id: 'enumID',
        //   },
        //   label: '列头-枚举',
        // },
        {
          field: {
            type: 'thumbnail',
            key: 'doctor_name',
          },
          label: '列头-缩略图',
        },
        {
          label: '操作',
          fields: [
            {
              type: 'interaction',
              label: '启用',
              authority_code: '',
              show_condition: true,
              action: {
                name: 'request',
                method: 'post',
                params: {
                  actId: '${_row.id}',
                },
                uri: '/start',
                onBeforeRequest: {
                  name: 'js',
                  code: 'Request.requestData.actId = Request.requestData.actId + 1;return Request;',
                },
                onBeforeResponse: {
                  name: 'js',
                  code: 'Response.responseData.status = Response.responseData.code;return Request;',
                },
                next: {
                  name: 'toast',
                  text: '${preActionResult.data.code === 0 ? \'启用成功\' : \'启用失败\'}',
                },
              },
            },
            {
              type: 'divider',
              text: '<span style="margin: 0 8px; background: red;">|||分隔符</span>',
            },
            {
              type: 'interaction',
              label: '详情',
              sortable: false,
              authority_code: '',
              show_condition: true,
              action: {
                name: 'link',
                uri: '/detail/${row.id}',
                next: '',
              },
            },
          ],
        },
      ],
    });
    const tableDataMap = ref([
      {
        data_id: '1',
        doctor_name: 'www.hahahha.com',
        doctor_time: 111,
        doctor_price: 10,
      },
      {
        data_id: '2',
        doctor_name: 'www.qq.com',
        doctor_time: 222,
        doctor_price: 9,
      },
    ]);
    const onMap = {
      'update:currentPage': (val) => {
        console.log('=======update:currentPage======');
        console.log(val);
      },
      'update:total': (val) => {
        console.log('=======update:total======');
        console.log(val);
      },
      'update:pageSize': (val) => {
        console.log('=======update:pageSize======');
        console.log(val);
      },
      'sort-change': (val) => {
        console.log('=======sort-change======');
        console.log(val);
      },
      'selection-change': (val) => {
        console.log('=======selection-change======');
        console.log(val);
      },
    };
    return {
      propsMap,
      tableDataMap,
      onMap,
    };
  },
  render() {
    const props = {
      ...this.propsMap,
      tableData: this.tableDataMap,
    };
    return h('table-test', {}, [
      h(SfTable, {
        ...props,
        on: {
          ...this.onMap,
        },
      }),
    ]);
  },
});
</script>

<style>

</style>
