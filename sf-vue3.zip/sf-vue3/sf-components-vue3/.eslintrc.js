// 腾讯代码规范：https://git.code.oa.com/standards/javascript

module.exports = {
  root: true,
  env: {
    browser: true,
    es6: true,
    node: true,
  },
  plugins: ['vue'],
  extends: ['plugin:vue/base', '@tencent/eslint-config-tencent', '@tencent/eslint-config-tencent/ts'],
  parser: 'vue-eslint-parser',
  parserOptions: {
    parser: '@typescript-eslint/parser',
    project: './tsconfig.json',
    createDefaultProgram: true
  },
  overrides: [
    {
      files: ['**/__tests__/*.{j,t}s?(x)', '**/tests/**/*.spec.{j,t}s?(x)'],
      env: {
        jest: true,
      },
    },
  ],
  globals: {
    document: true,
  },
  rules: {
    'no-console': 'off',
    'no-debugger': 'warn',
  },
};
