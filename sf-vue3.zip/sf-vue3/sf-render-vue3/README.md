### 项目结构介绍

- build 打包编译相关的方法和配置
- dist 编译产物
- packages 组件代码 (monorepo)
- play 开发时调试使用
- typings 类型声明
- tsconfig ts配置