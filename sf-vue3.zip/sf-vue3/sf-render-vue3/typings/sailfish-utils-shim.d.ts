declare module '@tencent/sailfish-utils';
