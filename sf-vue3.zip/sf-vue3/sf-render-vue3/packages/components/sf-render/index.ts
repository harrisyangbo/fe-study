import Render from './src/sf-render.vue';
import { withInstall } from '../../utils/common/with-install';
const SfRender = withInstall(Render);
export {
  SfRender,
};
export default SfRender;
