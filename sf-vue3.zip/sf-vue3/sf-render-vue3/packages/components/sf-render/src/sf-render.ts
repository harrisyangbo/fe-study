// 组件 props 及 公共方法
import { ref, computed, inject, getCurrentInstance } from 'vue';
import type { ExtractPropTypes } from 'vue';
import { validator, setProperty } from '@tencent/sailfish-utils';
import configAdapter from '../../../utils/render-utils/data-adapter';
import componentManage from './component-manage';
import { configToCamelCase } from '../../../utils/common/schema-handle';
export const renderProps = {
  businessConfig: {
    type: Object,
    default: null,
  },
  initiateModel: {
    type: Object,
    default: () => ({}),
  },
} as const;
export const renderHandle = (props, ctx) => {
  const {
    mpComponentStatus,
    mpLoadPromises,
    mpAllLoadPromisesCollected,
    mpStartWatchInputChange,
    mpPageLoadTriggered,
    mpDrawerContentChanged,
    mpPageLoadTriggeredChange,
    mpSetDrawerContentChanged,
  } = componentManage(ctx, getCurrentInstance());
  const componentTree = ref(null);
  const dataModel = ref({});
  const baseConfig = computed(() => props.businessConfig);
  const initiateModel = computed(() => props.initiateModel);
  const $mpSetDrawerContentChangedOfParent = inject('$mpSetDrawerContentChangedOfParent', null);
  const scriptContext = computed(() => ({
    $dataModel: dataModel.value, // 页面的数据实体
    $row: undefined, // 表格行数据实体
  }));
  // 初始化
  const init = () => {
    // TODO: 自定义组件处理
    // if (JSON.stringify(customComponentsList) !== '{}') {
    //   for (let key in customComponentsList) {
    //     let componentCategory = 'input';
    //     if (key.includes('logic')) componentCategory = 'logic';
    //     if (key.includes('table')) componentCategory = 'table';
    //     registerCustomComponent(null, componentCategory, key, customComponentsList[key]);
    //   }
    // }
    // 校验数据合法性
    try {
      validator.check(baseConfig);
    } catch (e) {
      // this.$message.error('页面配置数据存在错误');
      console.error(e);
      return;
    }
    // 重置状态数据
    resetData();
    // 整理配置数据
    // 整理配置数据
    const { businessConfig, dataModels } = configAdapter.make(props.businessConfig);
    Object.entries(initiateModel).forEach(([key, val]) => {
      setProperty(dataModel, key, val);
    });
    dataModel.value = dataModels;
    componentTree.value = configToCamelCase(businessConfig);
  };
  // 数据重置
  const resetData = () => {
    Object.keys(mpComponentStatus).forEach((item) => {
      delete mpComponentStatus[item];
    });
    mpPageLoadTriggeredChange(false);
    mpSetDrawerContentChanged(false);
    componentTree.value = null;
    dataModel.value = {};
  };
  init();
  return {
    mpComponentStatus,
    mpLoadPromises,
    mpAllLoadPromisesCollected,
    mpStartWatchInputChange,
    mpPageLoadTriggered,
    mpDrawerContentChanged,
    baseConfig,
    $mpSetDrawerContentChangedOfParent,
    scriptContext,
    init,
    componentTree,
    dataModel,
  };
};
export type RenderProps = ExtractPropTypes<typeof renderProps>;
