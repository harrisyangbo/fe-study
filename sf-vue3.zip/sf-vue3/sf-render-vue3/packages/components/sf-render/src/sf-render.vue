<script lang="ts">
import { computed, defineComponent, h, VNode } from 'vue';
import { renderProps, renderHandle } from './sf-render';
import { renderInput, renderTable, renderInteraction, renderLogic } from './component-render';
import { isInput, isLogic, isLayout, isInteraction, typer  } from '@tencent/sailfish-utils';
import _pickBy from 'lodash.pickby';
// TODO: 组件映射
const typeComponents = {
  form: 'div',
  table: 'span',
};
type RenderComponentTree = (componentNodes: {
  [key: string]: any
}, contextModel: {
    [key: string]: any
  }, parentNode?: any) => any;
export default defineComponent({
  name: 'SfRender',
  props: renderProps,
  emits: [
    'dialogShow',
    'dockerShow',
    'confirm',
    'cancel',
    'sailfishPageLoad',
  ],
  setup(props, ctx) {
    const baseConfig = computed(() => props.businessConfig);
    const {
      componentTree,
      dataModel,
      scriptContext,
      // businessConfig,
    } = renderHandle(props, ctx);
    const vNodeHandle = (componentNode, contextModel, slotName) => {
      if (isLayout(componentNode)) {
        const childrens = componentNode.children.map(el => vNodeHandle(el, contextModel, slotName));
        return h('el-row', {}, childrens);
      }
      if (isInput(componentNode)) {
        // 表单组件
        const inputComp = renderInput(componentNode, contextModel, slotName, scriptContext);
        // inputComp && childrenComponents.push(inputComp);
        return inputComp;
      }
      if (componentNode.name === 'table') {
        // 表格组件
        const tableComp = renderTable(componentNode, contextModel, scriptContext);
        // tableComp && childrenComponents.push(tableComp);
        return tableComp;
      }
      if (isInteraction(componentNode)) {
        // 交互组件
        const interactionComp = renderInteraction(componentNode, slotName, scriptContext);
        // interactionComp && childrenComponents.push(interactionComp);
        return interactionComp;
      }
      if (isLogic(componentNode)) {
        // 逻辑组件
        const logicComp = renderLogic(componentNode);
        // logicComp && childrenComponents.push(logicComp);
        return logicComp;
      }
      // 其它组件
      // childrenComponents.push(h(typeComponents[componentNode.type], {
      //   props,
      // }));
      return h(typeComponents[componentNode.name], {
        props,
      })
      ;
    };
    // 组装组件树
    const renderComponentTree: RenderComponentTree = (componentNodes, contextModel, parentNode?) => {
      let layoutHeaderSlot = false;
      let parentComponentId = '';
      console.log(parentNode);
      if (parentNode) {
        // 判断如果父组件是行布局组件，并且是否开启了头部插槽。如果layoutHeaderSlot为true，则将componentNodes中的第一个组件(表单块、表单组件、交互组件)放到头部插槽
        if (parentNode.type === 'row') {
          layoutHeaderSlot = parentNode.foldable && !parentNode.label;
        }
        // 如果父组件带有componentId，则当前子组件的componentId会拼接上父组件的componentId
        if (parentNode.__uniqueComponentId) {
          parentComponentId = `${parentNode.__uniqueComponentId}`;
        }
      };
      const childrenComponents: Array<VNode> = [];
      componentNodes.forEach((componentNode, ind) => {
        const slotName = ind === 0 && layoutHeaderSlot ? 'header' : 'default';
        if (componentNode.id) {
          // 父子componentId拼接起来，作为子组件的唯一componentId，保存在__uniqueComponentId属性上作为传递给ui组件的值
          // eslint-disable-next-line no-param-reassign
          componentNode.__uniqueComponentId = !parentComponentId ? componentNode.id : `${parentComponentId}.${componentNode.id}`;
        };
        // 组装组件属性对象
        const props = _pickBy(componentNode, (value, key) => !['key', 'children'].includes(key));
        props.componentId = componentNode.__uniqueComponentId;
        // TODO 将判断方法加入到 @tencent/sailfish-utils
        if (isLayout(componentNode)) {
          // container组件
          // 如果有子组件，则需要递归渲染子组件
          if (typer.getType(componentNode.children) === typer.EnumType.bArray
          && componentNode.children.length > 0) {
            const childrens = componentNode.children.map(el => vNodeHandle(el, contextModel, slotName));
            childrenComponents.push(h('div', {
              class: 'sf-render-container',
            }, childrens));
          } else {
            childrenComponents.push(vNodeHandle(componentNode, contextModel, slotName));
          }
        }
      });
      return childrenComponents;
    };
    return {
      baseConfig,
      renderComponentTree,
      componentTree,
      dataModel,
    };
  },
  render() {
    const children: Array<VNode> = [];
    const nodeTrees = this.renderComponentTree([this.componentTree], this.dataModel);
    if (!!(this as any).baseConfig.pageTitle) {
      children.push(h('header', {
        class: 'list-title',
      }, [this.baseConfig.pageTitle]));
    }
    // children.push(h('div', {
    //   class: 'sf-render-container',
    // }, [nodeTrees]));
    return h('div', { class: 'sf-page' }, [...children, ...nodeTrees]);
  },
});
</script>
<style scoped>
.list-title {
  height: 32px;
  line-height: 20px;
  list-style: none;
  font-size: 16px;
  font-weight: 500;
  color: #000000;
}
.list-template {
  background: #ffffff;
  padding: 16px 12px;
  height: calc(100% - 32px);
  overflow-y: auto;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.list-template-box {
  height: 100%;
}
</style>
