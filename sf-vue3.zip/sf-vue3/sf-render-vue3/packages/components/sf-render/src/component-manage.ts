/**
 * sailfish模板逻辑，管理加载的sailfish-ui组件
*/
import { reactive, ref, provide, onBeforeUnmount } from 'vue';
export default function (ctx, context) {
  const mpComponentStatus = reactive({});
  const mpLoadPromises = reactive({}); // 页面上onload触发的交互集合
  const mpAllLoadPromisesCollected = ref(false);
  const mpStartWatchInputChange = ref(false);
  const mpPageLoadTriggered = ref(false);
  const mpDrawerContentChanged = ref(false); // 该变量在父页面内使用，用来表示滑层页面内容是否有变化。子页面不能直接修改该变量x
  const mpSetDrawerContentChanged = (isChanged = false) => {
    mpDrawerContentChanged.value = isChanged;
  };
  const mpRegister = (id, status) => {
    mpComponentStatus[id] = status;
  };
  const mpSyncStatus = (id, status) => {
    mpComponentStatus[id] = Object.assign({}, mpComponentStatus[id], status);
    // 判断组件加载状态，只有当第一次全部组件达到ready状态时，才会触发PageLoad事件
    if (mpPageLoadTriggered) {
      return;
    }
    // if (Object.values(mpComponentStatus).map(o => o.$ready).every(r => r)) {
    // 	this.$data.$mpPageLoadTriggered = true;
    // 	this.$emit('sailfishPageLoad');
    // }
  };
  const mpPageLoadTriggeredChange = (status) => {
    mpPageLoadTriggered.value = status;
  };
  const mpUnRegister = (id) => {
    delete mpComponentStatus[id];
  };
  const mpRegisterLoadPromise = (id) => {
    mpLoadPromises[id] = null;
  };
  const mpSyncLoadPromise = (id, pro) => {
    mpLoadPromises[id] = pro;
    if (mpAllLoadPromisesCollected.value) {
      return;
    }
    const pros = Object.values(mpLoadPromises);
    if (pros.every(p => p)) {
      mpAllLoadPromisesCollected.value = true;
      // 等所有onload事件执行完毕之后，保存一份表单项数据的快照
      Promise.all(pros).finally(() => {
        mpStartWatchInputChange.value = true;
        console.log('onload logic finished! start watching input\'s change event!');
      });
    }
  };
  const mpUnRegisterLoadPromise = (id) => {
    delete mpLoadPromises[id];
  };
  provide('mpSetDrawerContentChanged', mpSetDrawerContentChanged);
  provide('mpRegister', mpRegister);
  provide('mpSyncStatus', mpSyncStatus);
  provide('mpUnRegister', mpUnRegister);
  provide('mpRegisterLoadPromise', mpRegisterLoadPromise);
  provide('mpSyncLoadPromise', mpSyncLoadPromise);
  provide('mpUnRegisterLoadPromise', mpUnRegisterLoadPromise);
  provide('mpPageLoadTriggeredChange', mpPageLoadTriggeredChange);
  provide('mpRoot', context);
  onBeforeUnmount(() => {
    console.log('emit sailfishBeforePageUnload event');
    ctx.emit('sailfishBeforePageUnload');
  });
  return {
    mpComponentStatus,
    mpLoadPromises,
    mpAllLoadPromisesCollected,
    mpStartWatchInputChange,
    mpPageLoadTriggered,
    mpDrawerContentChanged,
    mpSetDrawerContentChanged,
    mpPageLoadTriggeredChange,
  };
}
