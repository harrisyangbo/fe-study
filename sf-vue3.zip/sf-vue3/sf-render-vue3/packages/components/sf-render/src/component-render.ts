import _pickBy from 'lodash.pickby';
import { typer, getProperty, setProperty } from '@tencent/sailfish-utils';
import { h, VNode } from 'vue';
import { typeComponents } from '@tencent/sf-components-vue3';
const pickProps = (componentNode, excludes?) => {
  const e = excludes && excludes.length > 0
    ? excludes
    : ['type', 'key', 'children', 'name'];
  const attrs = _pickBy(componentNode, (value, key) => !e.includes(key));
  return attrs;
};
// 表单类组件渲染处理函数
export const renderInput = (componentNode, contextModel, slotName = 'default', scriptContext): VNode => {
  // 组装组件属性对象
  console.log(slotName);
  const props = pickProps(componentNode);
  props.componentId = componentNode.__uniqueComponentId;
  // 使用模板字符串引擎处理模板语法
  // if (typeof componentNode.readOnly === 'string') {
  //   const isTempArr = componentNode.readOnly.match(/\{\{[\s\S]*\}\}/g);
  //   if (isTempArr && isTempArr.length > 0) {
  //     const templateAnalyzer = new TemplateAnalyzer(componentNode.readOnly, '{{', '}}');
  //     const readOnly = templateAnalyzer.result(scriptContext) || false;
  //     props.readOnly = readOnly;
  //   }
  // }
  // 处理disabled 中的模板语法
  // if (typeof componentNode.disabled === 'string') {
  //   const isTempArr = componentNode.disabled.match(/\{\{[\s\S]*\}\}/g);
  //   if (isTempArr && isTempArr.length > 0) {
  //     const templateAnalyzer = new TemplateAnalyzer(componentNode.disabled, '{{', '}}');
  //     const disabled = templateAnalyzer.result(scriptContext) || false;
  //     props.disabled = disabled;
  //   }
  // }
  // 处理label 中的模板语法
  // if (componentNode.label && componentNode.label !== '') {
  //   const isTempArr = componentNode.label.match(/\{\{[\s\S]*\}\}/g);
  //   if (isTempArr && isTempArr.length > 0) {
  //     const templateAnalyzer = new TemplateAnalyzer(componentNode.label, '{{', '}}');
  //     let res = templateAnalyzer.result(scriptContext);
  //     if (typeof res === 'string') {
  //       res = res.replace(/\'/g, '').replace(/\"/g, '');
  //     }
  //     const label = res || componentNode.label;
  //     props.label = label;
  //   }
  // }
  // 表单组件
  const { key, defaultValue } = componentNode;
  // 处理key, 通过key 将组建和 contextModel(页面数据实体)进行双向绑定
  const keyIsArray = typer.getType(key) === typer.EnumType.bArray;
  // 该表单项是否属于编辑内容的范围，如果是的话，需要在关闭时提示doubleCheck
  if (keyIsArray) {
    props.modelValue = key.map((k: string | number, i: string | number) => ((typer.isNullOrUndefined(contextModel[k])
			&& !typer.isNullOrUndefined(defaultValue))
      ? defaultValue[i]
      : contextModel[k]));
  } else {
    props.modelValue = (typer.isNullOrUndefined(contextModel[key])
			&& !typer.isNullOrUndefined(defaultValue))
      ? defaultValue
      : contextModel[key];
  }
  // 获取grid宽度
  let {  grid } = componentNode;
  if (typer.getType(grid) !== typer.EnumType.bNumber) {
    grid = 6;
  }
  const on = {
    input: (newVal) => {
      if (keyIsArray) {
        key.forEach((k, i) => {
          // eslint-disable-next-line no-param-reassign
          contextModel[k] = newVal[i];
        });
      } else {
        // eslint-disable-next-line no-param-reassign
        contextModel[key] = newVal;
      }
    },
  };
  // 如果是reveal组件，传入context
  if (componentNode.type === 'reveal') {
    props.context = scriptContext;
  }
  // TODO: 应用权限组件控制显隐，目前所有权限通过 都为 true, 权限组件挪到 sf-render-vue3中
  return h('el-col', {
    props: {
      span: grid || 6,
    },
  }, [
    h(typeComponents[componentNode.type], {
      props,
      on,
    })]);
  // return h('sf-authority-item', {
  //   props: {
  //     showCondition: true,
  //     noRenderWhenNoShow: componentNode.noRenderWhenNoShow,
  //     authorityCode: componentNode.authorityCode,
  //     context: scriptContext,
  //   },
  //   slot: slotName || 'default',
  // }, [h('el-col', {
  //   props: {
  //     span: grid || 6,
  //   },
  // }, [
  //   h(typeComponents[componentNode.type], {
  //     props,
  //     on,
  //   }),
  // 	])]);
};

// 表格组件渲染处理函数
export const renderTable = (componentNode, contextModel, scriptContext) => {
  // 组装组件属性对象
  const props = pickProps(componentNode);
  props.componentId = componentNode.__uniqueComponentId;
  // 表格组件
  const { keyName } = componentNode;
  props.context = scriptContext;
  props.columns = componentNode.columns;
  props.tableData = contextModel[keyName];
  props.loading = props.tableData === null;
  const on = {};
  if (componentNode.pageIndex) {
    props.currentPage = getProperty(contextModel, componentNode.pageIndex);
    on['update:currentPage'] = (val) => {
      setProperty(contextModel, componentNode.pageIndex, val);
    };
  } else {
    props.currentPage = 1;
  }
  if (componentNode.totalCount) {
    props.total = getProperty(contextModel, componentNode.totalCount);
    on['update:total'] = (val) => {
      setProperty(contextModel, componentNode.totalCount, val);
    };
  } else {
    props.total = 0;
  }
  if (componentNode.pageSize) {
    props.pageSize = getProperty(contextModel, componentNode.pageSize);
    on['update:pageSize'] = (val) => {
      setProperty(contextModel, componentNode.pageSize, val);
    };
  } else {
    props.pageSize = 10;
  }
  if (componentNode.orderBy && componentNode.order) {
    on['sort-change'] = ({ field, order }) => {
      setProperty(contextModel, componentNode.orderBy, field.keyName);
      setProperty(contextModel, componentNode.order, order);
    };
  }
  if (componentNode.selection) {
    props.selection = true;
    const entitiesKeyPath = componentNode.selection;
    on['selection-change'] = (selection) => {
      setProperty(contextModel, entitiesKeyPath, selection);
    };
  }

  const tables = [h(typeComponents[componentNode.type], {
    props,
    on,
  })];
  // TODO: 需要包一层控制显隐的权限组件
  return h('dh-authority-item', {
    props: {
      showCondition: componentNode.showCondition,
      noRenderWhenNoShow: componentNode.noRenderWhenNoShow,
      authorityCode: componentNode.authorityCode,
      context: scriptContext,
    },
  }, tables);
};
// 交互组件渲染处理函数
export const renderInteraction = (componentNode, slotName = 'default', scriptContext) => {
  // 组装组件属性对象
  const props = pickProps(componentNode, ['type']);
  props.componentId = componentNode.__uniqueComponentId;
  props.context = scriptContext;
  return h('dh-authority-item', {
    props: {
      showCondition: componentNode.showCondition,
      noRenderWhenNoShow: componentNode.noRenderWhenNoShow,
      authorityCode: componentNode.authorityCode,
      context: scriptContext,
    },
    slot: slotName,
  }, [
    h(typeComponents[componentNode.type], {
      props,
    }),
  ]);
};
// 逻辑组件渲染处理函数
export const renderLogic = (componentNode) => {
  // 组装组件属性对象
  const props = pickProps(componentNode, ['type']);
  props.componentId = componentNode.__uniqueComponentId;
  /**
   * props.context = this.scriptContext;
   * logic组件的context需要在运行时动态设置，不要在渲染时固定设置好
   * 因为logic组件是通用的，调用者可能是不同的trigger，需要根据不同的trigger设置不同的上下文
   * 如果是dialog 组件，需要绑定事件
   * **/
  // 如果是dialog或者docker逻辑组件，需要绑定事件
  const on: any = {};
  // TODO: 处理弹窗绑定事件
  // if (componentNode.type === 'dialog') {
  //   on.showDialog = handleShowDialog;
  // } else if (componentNode.type === 'confirm') {
  //   on.confirm = handleConfirm;
  // } else if (componentNode.type === 'cancel') {
  //   on.cancel = handleCancel;
  // }
  return h(typeComponents[componentNode.type], {
    props,
    on,
  });
};
