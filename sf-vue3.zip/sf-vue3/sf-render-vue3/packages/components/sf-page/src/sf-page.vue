<template>
  <div
    class="sailfish-page"
    style="width: 100%; height: 100%;"
  >
    <SailfishRender
      :business-config="businessConfig"
      :initiate-model="initiateModel"
      :custom-components-list="customComponentsList"
      @dialogShow="exportDialogShow"
      @dockerShow="exportDockerShow"
      @confirm="exportConfirm"
      @cancel="exportCancel"
    >
      <!-- <template #dialog>
        <slot name="dialog" />
      </template>
      <template #docker>
        <slot name="docker" />
      </template> -->
    </SailfishRender>
  </div>
</template>

<script>
import { computed, defineComponent, ref } from 'vue';
import SailfishRender from '../../sf-render/src/sf-render.vue';
// import loadComponent from '../common/load_component';
// import { typeComponents, isCatalystComponent } from 'sailfish-ui';
export default defineComponent({
  name: 'SailfishPage',
  components: {
    SailfishRender,
  },
  props: {
    schemaConfig: {
      type: Object,
      default: null,
    },
    initiateModel: {
      type: Object,
      default: () => ({}),
    },
  },
  emits: [
    'dialogShow',
    'dockerShow',
    'confirm',
    'cancel',
  ],
  setup(props, ctx) {
    const loading = ref(true);
    const customComponentsList = ref({});
    const businessConfig = computed(() => props.schemaConfig);
    const exportDialogShow = (...params) => {
      ctx.$emit('dialogShow', ...params);
    };
    const exportDockerShow = (...params) => {
      ctx.$emit('dockerShow', ...params);
    };
    const exportConfirm = (...params) => {
      ctx.$emit('confirm', ...params);
    };
    const exportCancel = (...params) => {
      ctx.$emit('cancel', ...params);
    };
    const loadCustomComponent = async (newConfig) => {
      if (newConfig.content) {
        return Promise.resolve();
      }
    };

    return {
      loading,
      customComponentsList,
      exportDialogShow,
      exportDockerShow,
      exportConfirm,
      exportCancel,
      loadCustomComponent,
      businessConfig,
    };
  },
});
</script>
