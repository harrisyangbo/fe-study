// 组件 props 及 公共方法
import type { ExtractPropTypes } from 'vue';
export const pageProps = {
  schemaConfig: {
    type: Object,
    default: {},
  },
  pageTitle: {
    type: String,
    default: '',
  },
  components: {
    type: Array,
    default: [],
  },
} as const;

export type PageProps = ExtractPropTypes<typeof pageProps>;
