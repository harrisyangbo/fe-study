import Page from './src/sf-page.vue';
import { withInstall } from '../../utils/common/with-install';
const SfPage = withInstall(Page);
export {
  SfPage,
};
export default SfPage;
