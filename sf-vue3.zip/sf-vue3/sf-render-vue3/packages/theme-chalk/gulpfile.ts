/**
 * 打包样式
 * 用到的依赖：
 * pnpm install gulp-sass @type/gulp-sass
 * @type/sass @type/gulp-autoprefixer
 * gulp-autoprefixer
 * @type/gulp-clean-css
 * gulp-clean-css
 * sass -D -w
 * **/

import gulpSass from 'gulp-sass';
import dartSass from 'sass';
import autoprefixer from 'gulp-autoprefixer';
import cleanCss from 'gulp-clean-css';
import path from 'path';
import { series, src, dest } from 'gulp';
// 打包scss
function compile() {
  const sass = gulpSass(dartSass); // 生成编译方法
  // 返回流
  return src(path.relative(__dirname, './src/*.scss'))
    .pipe(sass.sync())
    .pipe(autoprefixer())
    .pipe(cleanCss())
    .pipe(dest('./dist/css'));
}
// 拷贝字体
function copyfont() {
  return src(path.resolve(__dirname, './src/fonts/**'))
    .pipe(cleanCss())
    .pipe(dest('./dist/fonts'));
}
// 拷贝所有样式到根目录dist
function copyAllStyles() {
  return src(path.resolve(__dirname, './dist/**'))
    .pipe(dest(path.resolve('../../dist/theme-chalk')));
}
export default series(
  compile,
  copyfont,
  copyAllStyles,
);
