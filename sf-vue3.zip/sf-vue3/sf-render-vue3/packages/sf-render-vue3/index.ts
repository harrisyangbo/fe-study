import SfPage from '@sf-render-vue3/components/sf-page';
import SfComponents from '@tencent/sf-components-vue3';
import type { App } from 'vue';

const components = [SfPage];

const install = (app: App) => {
  app.use(SfComponents);
  components.forEach(comp => app.use(comp));
};
export default {
  install,
};

export * from '@sf-render-vue3/components';
