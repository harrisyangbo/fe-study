import { configSchema, isLayout, isInput, isDataContainer, isInteraction, isLogic } from '@tencent/sailfish-lowcode-utils';
export const convertUnderscore = s => s.replace(/_+([a-zA-Z0-9])/g, (val, p1) => p1.toUpperCase());
export const convertComponent = (config, schema) => {
  if (schema.__index) {
    const newObj: any[] = [];
    config.forEach((elem) => {
      if (schema.__index.$childSchema) {
        newObj.push(convertComponent(elem, schema.__index.$childSchema));
      } else {
        newObj.push(configToCamelCase(elem));
      }
    });
    return newObj;
  }
  const newObj = {};
  Object.keys(config).forEach((key) => {
    if (schema[key]) {
      const newKey = convertUnderscore(key);
      if (schema[key].$childSchema) {
        newObj[newKey] = convertComponent(config[key], schema[key].$childSchema);
      } else {
        newObj[newKey] = configToCamelCase(config[key]);
      }
    } else if (schema['*']) {
      const newKey = convertUnderscore(key);
      newObj[newKey] = configToCamelCase(config[key]);
    } else {
      newObj[key] = configToCamelCase(config[key]);
    }
  });
  return newObj;
};
export const configToCamelCase = (obj) => {
  if (!!obj && typeof obj === 'object') {
    if (obj instanceof Array) {
      const newObj: any[] = [];
      obj.forEach((elem) => {
        newObj.push(configToCamelCase(elem));
      });
      return newObj;
    }
    let newObj = {};
    if (isLayout(obj)) {
      newObj = convertComponent(obj, configSchema.layout);
    } else if (isInput(obj)) {
      newObj = convertComponent(obj, configSchema.input);
    } else if (isDataContainer(obj)) {
      newObj = convertComponent(obj, configSchema.container);
    } else if (isInteraction(obj)) {
      newObj = convertComponent(obj, configSchema.interaction);
    } else if (isLogic(obj)) {
      newObj = convertComponent(obj, configSchema.logic);
    } else {
      Object.keys(obj).forEach((key) => {
        newObj[key] = configToCamelCase(obj[key]);
      });
    }
    return newObj;
  }
  return obj;
};
