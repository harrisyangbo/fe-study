export declare const convertUnderscore: (s: any) => any;
export declare const convertComponent: (config: any, schema: any) => {};
export declare const configToCamelCase: (obj: any) => any;
