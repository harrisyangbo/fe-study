declare function getType(obj: any): string;
declare function isObject(obj: any): boolean;
declare function isObjectNullOrUndefined(obj: any): boolean;
declare function isNullOrUndefined(v: any): boolean;
declare function isStringEmpty(str: any): boolean;
declare function getFloatInfo(n: any): {
    isNumber: boolean;
    isFloat: boolean;
    pointRightCount: number;
};
declare const _default: {
    EnumType: {
        bUndefined: string;
        bNull: string;
        bNumber: string;
        bBoolean: string;
        bString: string;
        bFunction: string;
        bRegExp: string;
        bArray: string;
        bDate: string;
        bError: string;
        bNode: string;
        bElement: string;
        bDocument: string;
        bArraylist: string;
        bObject: string;
    };
    getType: typeof getType;
    isObject: typeof isObject;
    isObjectNullOrUndefined: typeof isObjectNullOrUndefined;
    isNullOrUndefined: typeof isNullOrUndefined;
    isStringEmpty: typeof isStringEmpty;
    getFloatInfo: typeof getFloatInfo;
};
export default _default;
