declare const _default: {
    bUndefined: string;
    bNull: string;
    bNumber: string;
    bBoolean: string;
    bString: string;
    bFunction: string;
    bRegExp: string;
    bArray: string;
    bDate: string;
    bError: string;
    bNode: string;
    bElement: string;
    bDocument: string;
    bArraylist: string;
    bObject: string;
};
export default _default;
