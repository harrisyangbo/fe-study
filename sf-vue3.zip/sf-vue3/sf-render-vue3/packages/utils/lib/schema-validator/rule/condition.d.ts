export declare const ifHasValue: (value: any) => any;
export declare const whenTypeIs: (type: any, typeRange?: string[]) => any;
