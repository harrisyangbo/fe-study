export declare function checkLogic({ component_id, type, uri, name, method, target, script, next, }?: any): void;
