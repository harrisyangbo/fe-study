export declare function isInput(t: any): boolean;
export declare function isDataContainer(t: any): boolean;
export declare function isInteraction(t: any): boolean;
export declare function isLayout(t: any): boolean;
export declare function isLogic(t: any): boolean;
export declare function isCatalystComponent(t: any): boolean;
