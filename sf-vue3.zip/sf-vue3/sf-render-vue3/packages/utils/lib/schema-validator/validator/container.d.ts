export declare function checkContainer({ type, id, name, components, key, }?: any): void;
