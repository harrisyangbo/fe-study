export declare function checkInteraction({ id, type, name, trigger, label, main, logic, authority_code, show_condition, }?: any): void;
