export declare function checkInput({ id, type, label, grid, key, name, default_value, show_condition, read_only, clearable, options_id, uri, mode, edit_content, event, }?: any): void;
