export declare function checkTable({ id, type, key, name, show_condition, children, columns, page_index, page_size, total_count, order_by, order, selection, }?: any): void;
