export declare const check: (schemaConfig: any) => void;
