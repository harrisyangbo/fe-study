declare function guid(): string;
export default guid;
