interface RootLayout {
    type: String;
    children: Array<any>;
}
declare function makeLayout(layout: any, getComponentById: any): RootLayout;
declare function makeContent(content: any): {
    componentDictionary: {};
    logicComponents: any[];
    dataModel: {};
};
declare const _default: {
    make(originalBusinessConfig: any): {
        originalBusinessConfig: any;
        businessConfig: {};
        dataModels: {
            a: string;
        };
    };
};
export default _default;
export { makeContent, makeLayout, };
