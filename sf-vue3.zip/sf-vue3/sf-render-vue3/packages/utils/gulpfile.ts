
import { buildPackages } from '../../build/packages';
export default buildPackages(__dirname, 'utils');
