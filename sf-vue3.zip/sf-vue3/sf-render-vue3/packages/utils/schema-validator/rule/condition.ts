import typer from '../module-type/index';
import * as rules from './index';

const ruleNames = Object.keys(rules);
export const ifHasValue = (value: any): any => {
  const continueFlow = !typer.isNullOrUndefined(value);

  const ret = {};

  ruleNames.forEach((ruleName) => {
    ret[ruleName] = function (...params) {
      if (continueFlow) {
        rules[ruleName](...params);
      }
      return ret;
    };
  });

  return ret;
};
interface Ret {
  ifHasValue?: any
  [key: string]: any
}
export const whenTypeIs = (type, typeRange: string[] = []): any => {
  let continueFlow = typeRange.includes(type);

  const ret: Ret = {};

  ruleNames.forEach((ruleName) => {
    ret[ruleName] = function (...params) {
      if (continueFlow) {
        try {
          rules[ruleName](...params);
        } catch (e) {
          throw `对于${type}类型，${e}`;
        }
      }
      return ret;
    };
  });

  ret.ifHasValue = function (value) {
    if (continueFlow) {
      continueFlow = !typer.isNullOrUndefined(value);
    }
    return ret;
  };

  return ret;
};
