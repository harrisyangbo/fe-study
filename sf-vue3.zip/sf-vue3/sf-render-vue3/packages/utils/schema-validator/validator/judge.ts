import { INPUT_TYPES, DATA_CONTAINER_TYPES, INTERACTION_TYPES, LAYOUT_TYPES, LOGIC_TYPES } from './const';

function valid(t) {
  if (!t) {
    throw new Error('判断配置组件类型失败，传入的配置对象为空');
  }
}

export function isInput(t) {
  valid(t);
  return INPUT_TYPES.includes(t.type);
}

export function isDataContainer(t) {
  valid(t);
  return DATA_CONTAINER_TYPES.includes(t.type);
}

export function isInteraction(t) {
  valid(t);
  return INTERACTION_TYPES.includes(t.type);
}

export function isLayout(t) {
  valid(t);
  return LAYOUT_TYPES.includes(t.type);
}

export function isLogic(t) {
  valid(t);
  return LOGIC_TYPES.includes(t.type);
}

export function isCatalystComponent(t) {
  valid(t);
  const currentTypes: string[] = ([] as string[])
    .concat(INPUT_TYPES, DATA_CONTAINER_TYPES, INTERACTION_TYPES, LAYOUT_TYPES, LOGIC_TYPES);
  return currentTypes.includes(t.type);
}
