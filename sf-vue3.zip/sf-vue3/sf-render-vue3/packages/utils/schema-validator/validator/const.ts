// 表单输入类组件类型
export const INPUT_TYPES: string[] = [
  'text',
  'dropdown',
  'keyword',
  'calendar',
  'radio',
  'checkbox',
  'time',
  'switch',
  'hidden',
  'textarea',
  'reveal',
  'form',
];
// 容器类组件类型
export const DATA_CONTAINER_TYPES: string[] = [
  'table',
  'block',
  'container',
];
// 表格单元格类组件类型
export const FIELD_TYPES: string[] = [
  'raw',
  'enum_text',
  'enum_icon',
  'timespan',
  'datetime',
  'money',
  'thumbnail',
  'audio',
  'divider',
  'interaction',
];
// 交互类组件类型
export const INTERACTION_TYPES: string[] = [
  'interaction',
];
// 逻辑类组件类型
export const LOGIC_TYPES: string[] = [
  'page',
  'ajax',
  'dialog',
  'docker',
  'js',
  'confirm',
  'cancel',
  'validate',
];
// 布局类组件类型
export const LAYOUT_TYPES: string[] = [
  'row',
  'col',
];
// 时间组件模式
export const CALENDAR_MODES = [
  'datetime',
  'date',
  'datetimerange',
  'daterange',
];
export const AJAX_METHODS = [
  'get',
  'post',
];
// 布局组件模式
export const LAYOUT_MODES = [
  'flex',
];
export const LAYOUT_FOLD_MODES = [
  'head',
  'button',
];
// 布局组件flex配置
export const LAYOUT_JUSTIFY = [
  'start',
  'end',
  'center',
  'space-around',
  'space-between',
];
// 布局组件flex配置
export const LAYOUT_ALIGN = [
  'top',
  'middle',
  'bottom',
];
