/**
 * 表单类组件配置校验器
 */
import {
  mustBeStringAndNotEmpty,
} from '../rule/index';
import {
  ifHasValue,
  whenTypeIs,
} from '../rule/condition';
import {
  CALENDAR_MODES,
} from './const';

export function checkInput({
  id,
  type,
  label,
  grid,
  key,
  name,
  default_value,
  show_condition = true,
  read_only = false,
  clearable = true,
  options_id,
  uri,
  mode,
  edit_content = false,
  event,
}: any = {}) {
  try {
    mustBeStringAndNotEmpty('type', type.trim()); // 类型校验
    mustBeStringAndNotEmpty('name', name.trim()); // 组件名校验
    ifHasValue(id).mustBeStringAndNotEmpty('component_id', id); // id 校验
    ifHasValue(label).mustBeStringAndNotEmpty('label', label); // label 校验
    ifHasValue(grid).mustBeNumber('grid', grid); // 布局配置校验
    ifHasValue(event).mustBeArray('event', event);
    // 组件key校验
    whenTypeIs(name, ['text', 'dropdown', 'radio', 'checkbox', 'time', 'switch', 'hidden', 'textarea']).mustBeStringAndNotEmpty('key', key);
    whenTypeIs(name, ['calendar']).mustBeStringOrStringArrayAndNotEmpty('key', key);
    whenTypeIs(name, ['calendar']).mustBeOneOfEnumValues('mode', mode, CALENDAR_MODES);
    if (Array.isArray(key)) {
      ifHasValue(default_value).mustBeArrayAndNotEmpty('default_value', default_value);
    }
    ifHasValue(show_condition).mustBeStringOrBoolean('show_condition', show_condition);
    ifHasValue(read_only).mustBeStringOrBoolean('read_only', read_only);
    ifHasValue(clearable).mustBeStringOrBoolean('clearable', clearable);
    whenTypeIs(name, ['dropdown', 'keyword', 'radio', 'checkbox']).mustBeStringAndNotEmpty('options_id', options_id);
    whenTypeIs(name, ['text', 'keyword']).ifHasValue(uri)
      .mustBeString('uri', uri);
    ifHasValue(edit_content).mustBeBoolean('edit_content', edit_content);
  } catch (e) {
    // eslint-disable-next-line prefer-rest-params
    throw `表单组件配置错误: ${e}。配置如下：${JSON.stringify(arguments[0], null, 2)}`;
  }
}
