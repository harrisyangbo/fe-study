/**
 * 交互组件配置校验器
 */
import {
  mustBeStringAndNotEmpty,
  mustBeObject,
} from '../rule/index';
import {
  ifHasValue,
} from '../rule/condition';

export function checkInteraction({
  id,
  type,
  name,
  trigger,
  label,
  main = false,
  logic,
  authority_code,
  show_condition = true,
}: any = {}) {
  try {
    mustBeStringAndNotEmpty('type', type.trim());
    mustBeStringAndNotEmpty('name', name.trim());
    ifHasValue(id).mustBeStringAndNotEmpty('id', id);
    mustBeObject('trigger', trigger);
    ifHasValue(trigger.load).mustBeBoolean('trigger.load', trigger.load);
    ifHasValue(trigger.unload).mustBeBoolean('trigger.unload', trigger.unload);
    ifHasValue(trigger.button).mustBeBoolean('trigger.button', trigger.button);
    ifHasValue(trigger.watch).mustBeArray('trigger.watch', trigger.watch);
    if (trigger.button) {
      mustBeStringAndNotEmpty('label', label);
    }
    ifHasValue(main).mustBeBoolean('main', main);
    ifHasValue(logic).mustBeStringAndNotEmpty('logic', logic);
    ifHasValue(authority_code).mustBeString('authority_code', authority_code);
    ifHasValue(show_condition).mustBeStringOrBoolean('show_condition', show_condition);
  } catch (e) {
    throw `交互组件配置错误: ${e}。配置如下：
${JSON.stringify(arguments[0], null, 2)}`;
  }
}
