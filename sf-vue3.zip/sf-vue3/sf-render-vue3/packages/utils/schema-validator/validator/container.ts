/**
 * cantainers 配置校验器
 */
import {
  mustBeStringAndNotEmpty,
  mustBeArrayAndNotEmpty,
} from '../rule/index';
import typer from '../module-type/index';
import { isInput, isDataContainer, isInteraction, isLogic } from './judge';
import { checkInput } from './input';
import { checkTable } from './table';
import { checkInteraction } from './interaction';
import { checkLogic } from './logic';

const traverseContent = (components, parentConfig = null, needValidateIfInLayout = false) => {
  // 对 container 中配置的组件进行校验
  components.forEach((child) => {
    const typeOfChild = typer.getType(child);
    if (typeOfChild === typer.EnumType.bObject) {
      if (isInput(child)) {
        // 表单类组件校验
        checkInput(child);
      } else if (isDataContainer(child)) {
        checkTable(child);
        if (child.type === 'block') {
          if (typer.getType(child.children) === typer.EnumType.bObject) {
            if (child.children.type === 'block') {
              traverseContent([child.children], child, true);
            } else {
              throw 'block组件的children配置错误：如果children是对象类型，那么只能配置成另一个block组件';
            }
          } else {
            traverseContent(child.children, child, needValidateIfInLayout);
          }
        }
      } else if (isInteraction(child)) {
        checkInteraction(child);
      } else if (isLogic(child)) {
        if (parentConfig) {
          throw `逻辑组件[${child.component_id}]禁止嵌套在其它组件内部`;
        }
        checkLogic(child);
        // 逻辑组件不需要手动配置到布局区
        // if (child.component_id && componentIdsInLayout.includes(child.component_id)) {
        //   throw `逻辑组件[${child.component_id}]不需要手动配置到布局区`;
        // }
      } else {
        throw `内容区配置了不合法的组件。内容区只能配置表单组件、数据容器组件、交互组件和逻辑组件。配置如下：${JSON.stringify(child, null, 2)}`;
      }
    }
  });
};
export function checkContainer({
  type,
  id,
  name,
  components,
  key,
}: any = {}) {
  try {
    mustBeStringAndNotEmpty('type', type.trim());
    mustBeStringAndNotEmpty('id', id.trim());
    mustBeStringAndNotEmpty('key', key.trim());
    mustBeStringAndNotEmpty('name', name.trim());
    mustBeArrayAndNotEmpty('components', components);
    // 校验组件内容
    traverseContent(components);
  } catch (e) {
    // eslint-disable-next-line prefer-rest-params
    throw `数据容器组件配置错误: ${e}。配置如下：${JSON.stringify(arguments[0], null, 2)}`;
  }
}
