import typer from '../module-type/index';
import { checkContainer } from './container';

export const check = function (schemaConfig: any) {
  // const componentIdsInLayout = [];
  const { containers } = schemaConfig;
  // 校验顶层配置
  traversePage(schemaConfig);
  // containers 配置校验
  traverseContainer(containers);
  // traverseLayout(layout);

  function traversePage(config) {
    const typeConfig = typer.getType(config);
    if (!(typeConfig === typer.EnumType.bObject)) {
      throw 'Schema 配置必须为一个 Object！请传入正确的配置';
    }
  };
  function traverseContainer(containers) {
    const containersType = typer.getType(containers);
    if (containersType === typer.EnumType.bArray && containers.length > 0) {
      containers.forEach((container) => {
        // 校验container容器配置
        checkContainer(container);
      });
    } else {
      throw 'containers 配置必须为一个数组且元素 > 0';
    }
  }
  //   function traverseLayout(layoutConfig = {}) {
  //     layoutConfig.forEach((child) => {
  //       const typeOfChild = typer.getType(child);
  //       if (typeOfChild === typer.EnumType.bString) {
  //         componentIdsInLayout.push(child);
  //       } else if (typeOfChild === typer.EnumType.bObject && isLayout(child)) {
  //         checkLayout(child);
  //         if (child.children) {
  //           traverseLayout(child.children);
  //         }
  //       } else {
  //         throw `布局区配置了不合法的组件。布局区只能配置组件实例ID或者嵌套另外的布局组件。配置如下：
  // ${JSON.stringify(child, null, 2)}`;
  //       }
  //     });
  //   }
};
