<template>
	测试效果
	<SfPage :schemaConfig="schema" :initiateModel="{}" />
</template>

<script>
import SfPage from '../packages/components/sf-page/src/sf-page.vue';
import { ref } from 'vue';
export default {
  components: {
    SfPage,
  },
  setup() {
    const schema = ref({
      pageTitle: '列表页',
      layout: [
        {
          type: 'row',
          foldable: false,
          gutter: 32,
          label: '这里是标题',
          icon: {
            class: 'el-icon-share',
            color: 'red',
          },
          children: [
            'teacher_name',
            'teacher_reveal',
            'account_type',
            'cus_field',
            'connect_timing',
            'm_date',
            'm_date_time',
            'multiKeyName',
            'm_time_range',
            'm_date_range',
            'sex',
            'city',
          ],
        },
        {
          type: 'row', // 行/列
          label: '第二部分', // 标题
          foldable: false, // 是否可折叠
          gutter: 32, // 栅格间隔
          style_object: { // 样式
            'line-height': '55px',
          },
          children: [ // 此块下的组件
            'teacher_name_two',
            'account_type_two',
            'connect_timing_two',
            'm_date_two',
            'm_date_time_two',
            'multiKeyName_two',
          ],
        },
        {
          type: 'row',
          mode: 'flex',
          align: 'middle',
          style_object: {
            'margin-bottom': '6px',
          },
          children: [
            'search_action',
          ],
        },
        {
          type: 'row',
          mode: 'flex',
          justify: 'end',
          children: [
            'audit_action',
            'docker_action',
          ],
        },
        {
          type: 'row',
          children: [
            'data_table',
          ],
        },
      ],
      tabs: 'teacher_and_student',
      content: [
        {
          component_id: 'teacher_name',
          type: 'text',
          label: '教师姓名',
          key_name: 'name',
          placeholder: '教师姓名',
          show_condition: '',
          mode: 'compound',
          compound_expands: {
            slot: 'append',
            content: '后置内容',
          },
        },
        {
          component_id: 'teacher_reveal',
          type: 'reveal',
          key_name: 'teacher_reveal',
          prev: '前面',
          append: '后面',
        },
        {
          component_id: 'connect_timing',
          type: 'dropdown',
          label: '沟通节点',
          key_name: 'connect_timing',
          options_id: 'connection_timing',
        },
        {
          component_id: 'cus_field',
          type: 'cascaderSelect',
          o_label: '自定义筛选条件',
          key_name: 'cus_field',
        },
        {
          component_id: 'multiKeyName',
          type: 'multiKeyName',
          oLabel: '多字段筛选条件',
          key_name: ['cus_multi_field_1', 'cus_multi_field_2'],
        },
        {
          component_id: 'm_date',
          mode: 'date',
          type: 'calendar',
          label: '日历(date)',
          key_name: 'm_date',
        },
        {
          component_id: 'm_date_time',
          mode: 'datetime',
          type: 'calendar',
          label: '日历(datetime)',
          key_name: 'm_date_time',
        },
        {
          component_id: 'm_date_two',
          mode: 'date',
          type: 'calendar',
          label: '日历(date)',
          key_name: 'm_date_two',
          grid: 8,
        },
        {
          component_id: 'm_date_time_two',
          mode: 'datetime',
          type: 'calendar',
          label: '日历(datetime)',
          key_name: 'm_date_time_two',
          grid: 8,
        },
        {
          component_id: 'm_time_range',
          mode: 'datetimerange',
          type: 'calendar',
          label: '日历(datetimerange)',
          key_name: [
            'start_time',
            'end_time',
          ],
          grid: 12,
        },
        {
          component_id: 'm_date_range',
          mode: 'daterange',
          type: 'calendar',
          label: '日历(daterange)',
          key_name: [
            'start_date',
            'end_date',
          ],
          grid: 12,
        },
        {
          component_id: 'sex',
          type: 'radio',
          label: '性别',
          key_name: 'sex',
          options_id: 'sex',
        },
        {
          component_id: 'city',
          type: 'checkbox',
          label: '城市',
          key_name: 'city',
          options_id: 'city',
        },
        {
          component_id: 'teacher_name_two',
          type: 'text',
          label: '教师姓名',
          key_name: 'name_two',
          grid: 12,
          show_condition: '',
        },
        {
          component_id: 'account_type_two',
          type: 'dropdown',
          label: '账号类型',
          key_name: 'acccount_type_two',
          options_id: 'account_type',
          grid: 12,
        },
        {
          component_id: 'connect_timing_two',
          type: 'dropdown',
          label: '沟通节点',
          key_name: 'connect_timing_two',
          options_id: 'connection_timing',
          grid: 8,
        },
        {
          component_id: 'multiKeyName_two',
          type: 'multiKeyName',
          oLabel: '多字段筛选条件',
          key_name: ['cus_multi_field_3', 'cus_multi_field_4'],
          grid: 8,
        },
        {
          component_id: '333',
          type: 'block',
          key_name: 'tableManager',
          show_condition: false,
          children: [{
            component_id: '222',
            type: 'block',
            key_name: 'pagination',
            show_condition: false,
            children: [
              {
                component_id: '111',
                type: 'hidden',
                key_name: 'currentPage',
                default_value: 1,
              },
              {
                type: 'hidden',
                key_name: 'total',
                default_value: 0,
              },
              {
                type: 'hidden',
                key_name: 'pageSize',
                default_value: 10,
              },
            ],
          },
          {
            type: 'block',
            key_name: 'sorter',
            show_condition: false,
            children: [
              {
                type: 'hidden',
                key_name: 'orderBy',
              },
              {
                type: 'hidden',
                key_name: 'sort',
              },
            ],
          }, {
            type: 'hidden',
            key_name: 'entities',
            default_value: [],
          }],
        },
        {
          component_id: 'data_table',
          type: 'table',
          key_name: 'data_list',
          page_index: 'tableManager.pagination.currentPage',
          total_count: 'tableManager.pagination.total',
          page_size: 'tableManager.pagination.pageSize',
          order_by: 'tableManager.sorter.orderBy',
          order: 'tableManager.sorter.sort',
          selection: 'tableManager.entities',
          columns: [
            {
              field: {
                type: 'raw',
                key_name: 'component_id',
                sortable: false,
              },
              label: '编号',
            },
            {
              field: {
                type: 'interaction',
                key_name: 'name',
                sortable: false,
                authority_code: '',
                show_condition: true,
                logic: 'docker_action_logic',
              },
              label: '教师姓名',
            },
            {
              label: '自定义数据字段组件',
              field: {
                key_name: 'evaluation',
                type: 'convertField',
                options_id: 'course_evaluation',
              },
            },
            {
              tips: '性别说明',
              field: {
                type: 'enum_text',
                key_name: 'sex',
                sortable: false,
                options_id: 'sex',
                show_condition: true,
              },
              label: '性别',
            },
            {
              field: {
                type: 'raw',
                key_name: 'age',
                sortable: false,
                show_condition: true,
              },
              label: '年龄',
            },
            {
              label: '课堂评价',
              field: {
                key_name: 'evaluation',
                type: 'enum_text',
                sortable: true,
                options_id: 'course_evaluation',
              },
            },
            {
              field: {
                type: 'datetime',
                format: 'yyyy-MM-dd hh:mm:ss.S',
                key_name: 'start_time',
                sortable: true,
                show_condition: true,
              },
              label: '开始时间',
            },
            {
              label: '平均课堂时间',
              field: {
                key_name: 'average_lesson_duration',
                type: 'timespan',
                sortable: true,
                format: 'mm分钟',
              },
            },
            {
              label: '课堂单价',
              field: {
                key_name: 'price',
                type: 'money',
                sortable: true,
              },
            },
            {
              label: '上课截屏',
              field: {
                key_name: 'lesson_screenshot',
                type: 'thumbnail',
                sortable: false,
              },
            },
            {
              label: '录音评价',
              field: {
                key_name: 'evaluation_record',
                type: 'audio',
              },
            },
            {
              label: '操作',
              fields: [
                {
                  type: 'interaction',
                  label: '审核',
                  sortable: false,
                  authority_code: '',
                  show_condition: true,
                  logic: 'audit_action_logic',
                  action_name: '列表中审核按钮',
                  action_args: {
                    a_a: 123,
                    b_b: 'text',
                  },
                },
                {
                  type: 'divider',
                  text: '<span style=\'margin: 0 8px; background: red;\'>|||</span>',
                },
                {
                  type: 'interaction',
                  label: '详情',
                  sortable: false,
                  authority_code: '',
                  show_condition: true,
                  logic: 'docker_action_logic',
                  action_name: '列表中详情按钮',
                  action_args: {
                    a_a: 123,
                    b_b: 'text',
                  },
                },
              ],
            },
          ],
        },
        {
          component_id: 'search_action',
          type: 'interaction',
          label: '搜索',
          trigger: {
            load: true,
            button: true,
            watch: [
              'name',
              'acccount_type',
              'tableManager.pagination.currentPage',
              'tableManager.pagination.pageSize',
              'tableManager.sorter',
            ],
            unload: false,
          },
          authority_code: '',
          show_condition: '',
          logic: 'search_action_1',
          main: true,
          action_name: '搜索逻辑按钮',
          action_args: {
            a_a: 123,
            b_b: 'text',
          },
        },
        {
          component_id: 'search_action_1',
          type: 'js',
          script: `
        function (prevResult) {
          let o = {
            select_type: $dataModel.select_type,
            select_content: $dataModel.select_content,
            name: $dataModel.name,
            acccount_type: $dataModel.acccount_type,
            connect_timing: $dataModel.connect_timing,
            m_date: $dataModel.m_date,
            m_date_time: $dataModel.m_date_time,
            start_time: $dataModel.start_time,
            end_time: $dataModel.end_time,
            start_date: $dataModel.start_date,
            end_date: $dataModel.end_date,
            sex: $dataModel.sex,
            city: $dataModel.city,
            page_size: $dataModel.tableManager.pagination.pageSize,
            page: $dataModel.tableManager.pagination.currentPage,
            order_by: $dataModel.tableManager.sorter.orderBy || null,
            sort: $dataModel.tableManager.sorter.sort || null
          };
          return {
            next: 'search_action_2',
            params: o
          };
        }
      `,
        },
        {
          component_id: 'search_action_2',
          type: 'ajax',
          uri: '/api/mock/teacher/list',
          target: {
            data_list: 'list',
            'tableManager.pagination.total': 'total',
          },
          next: '',
        },
        {
          component_id: 'audit_action',
          type: 'interaction',
          label: '审核',
          trigger: {
            button: true,
          },
          authority_code: '',
          show_condition: '',
          logic: 'confirm_before_audit',
        },
        {
          component_id: 'confirm_before_audit',
          type: 'demoConfirm',
          text: '确认要做此操作吗？',
          next: 'audit_action_logic',
        },
        {
          component_id: 'audit_action_logic',
          type: 'js',
          script: `
        function (prevResult) {
          let o = [...$dataModel.tableManager.entities];
          return {
            next: 'audit_action_logic_1',
            params: o
          };
        }
      `,
        },
        {
          component_id: 'audit_action_logic_1',
          type: 'ajax',
          uri: '/api/mock/teacher/audit',
          method: 'post',
          next: '',
        },
        {
          component_id: 'docker_action',
          type: 'interaction',
          label: '打开滑层',
          trigger: {
            button: true,
          },
          authority_code: '',
          show_condition: '',
          logic: 'docker_action_logic',
        },
        {
          component_id: 'docker_action_logic',
          type: 'docker',
          uri: '/catalyst/teacher/form',
          next: '',
        },
      ],
    });
    return {
      schema,
    };
  },
};
</script>

<style>

</style>
